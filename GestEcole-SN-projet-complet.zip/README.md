# GestEcole SN - Gestion Scolaire Senegalaise

Application de gestion scolaire pour le Senegal, construite avec Next.js, TypeScript, Tailwind CSS et Electron.

## Fonctionnalites

- **Tableau de bord** - Vue d'ensemble de l'ecole
- **Gestion des eleves** - Inscription, fiches individuelles
- **Gestion des classes** - Organisation des classes
- **Gestion des essais** - 7 onglets (Parametres, Candidats, Notes, Resultats, Bulletins, Statistiques, Sujets)
- **Gestion des notes** - Saisie et calcul des notes
- **Gestion des presences** - Suivi de la presence
- **Emploi du temps** - Planning des cours
- **Bulletins** - Generation des bulletins scolaires

## Technologies

- Next.js 16 + TypeScript
- Tailwind CSS 4 + shadcn/ui
- Zustand (store avec persistance localStorage)
- Electron (application desktop)
- electron-builder (packaging .exe, .AppImage, .dmg)

---

## 🚀 Creer le .exe avec GitHub Actions (GRATUIT)

### Etape 1 : Creer un compte GitHub

1. Allez sur **https://github.com** et creez un compte (gratuit)
2. Cliquez sur **"New repository"**
3. Nommez-le `GestEcole-SN` (ou un autre nom)
4. Cochez **"Public"** ou **"Private"** (les deux fonctionnent)
5. Cliquez sur **"Create repository"**

### Etape 2 : Uploader le projet

1. Sur la page de votre nouveau repo, cliquez sur **"uploading an existing file"**
2. Glissez-deposez le fichier ZIP du projet
3. Cliquez sur **"Commit changes"**

### Etape 3 : Lancer la compilation

1. Allez dans l'onglet **"Actions"** de votre repo
2. Sur la gauche, cliquez sur **"Build GestEcole SN"**
3. Cliquez sur le bouton **"Run workflow"** (a droite)
4. Cliquez sur **"Run workflow"** (bouton vert)
5. Attendez environ 15-30 minutes

### Etape 4 : Telecharger le .exe

1. Une fois termine, cliquez sur le build ( coche verte )
2. En bas dans **"Artifacts"**, telechargez **"GestEcole-SN-Windows"**
3. Le fichier .exe est dedans !

---

## 📦 Lancer manuellement une release avec tag

Pour creer une version officielle avec les 3 fichiers (.exe, AppImage, .dmg) :

1. Allez dans votre repo GitHub
2. Cliquez sur **"Releases"** > **"Draft a new release"**
3. Dans **"Choose a tag"**, tapez `v1.0.0` puis **"Create new tag"**
4. Cliquez sur **"Publish release"**
5. GitHub Actions va compiler les 3 versions automatiquement
6. Les fichiers seront attaches a la release pour etre telecharges

---

## 💻 Development local

```bash
# Installer les dependances
npm install

# Lancer en mode developpement
npm run dev

# Build production (web)
npm run build
npm run start

# Build Electron (desktop)
npm run electron:build
```
