import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: process.env.ELECTRON === "true" ? "export" : "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
