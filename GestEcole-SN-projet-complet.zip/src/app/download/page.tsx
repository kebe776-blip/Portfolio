'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Download, Loader2, ArrowLeft } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export default function DownloadPage() {
  const [loading, setLoading] = useState(false);

  const handleDownload = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/download');
      if (!response.ok) throw new Error('Erreur');
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'GestEcole-SN-backup.zip';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      toast({ title: 'Succès', description: 'Téléchargement démarré !' });
    } catch {
      toast({ title: 'Erreur', description: 'Impossible de télécharger', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-cyan-50 to-blue-50">
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center space-y-6">
        <div className="w-20 h-20 bg-cyan-100 rounded-full flex items-center justify-center mx-auto">
          <Download className="w-10 h-10 text-cyan-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">GestEcole SN — Sauvegarde</h1>
          <p className="text-gray-500 mt-2">
            Téléchargez une copie complète de votre projet (6.9 Mo).
            Ce fichier ZIP contient tout le code source et les données.
          </p>
        </div>
        <Button
          size="lg"
          className="bg-cyan-600 hover:bg-cyan-700 w-full h-14 text-lg"
          onClick={handleDownload}
          disabled={loading}
        >
          {loading ? (
            <><Loader2 className="w-5 h-5 mr-2 animate-spin" />Téléchargement...</>
          ) : (
            <><Download className="w-5 h-5 mr-2" />Télécharger le ZIP</>
          )}
        </Button>
        <p className="text-xs text-gray-400">Pour restaurer : décompressez + npm install + npm run dev</p>
      </div>
    </div>
  );
}
