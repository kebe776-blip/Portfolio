'use client';

import { useState, useEffect } from 'react';
import { SidebarProvider, SidebarInset, SidebarTrigger } from '@/components/ui/sidebar';
import { AppSidebar } from '@/components/app-sidebar';
import { DashboardView } from '@/components/dashboard-view';
import { ElevesView } from '@/components/eleves-view';
import { ClassesView } from '@/components/classes-view';
import { NotesView } from '@/components/notes-view';
import { BulletinsView } from '@/components/bulletins-view';
import { PresencesView } from '@/components/presences-view';
import { EmploiDuTempsView } from '@/components/emploi-du-temps-view';
import { ParametresView } from '@/components/parametres-view';
import { Separator } from '@/components/ui/separator';
import { useAppStore } from '@/lib/store';
import type { ViewType } from '@/lib/types';

const viewLabels: Record<ViewType, string> = {
  'dashboard': 'Tableau de Bord',
  'eleves': 'Élèves',
  'eleve-ajouter': 'Ajouter un élève',
  'eleve-liste': 'Liste des élèves',
  'eleve-dossier': 'Dossier élève',
  'eleve-affectation': 'Affectation par classe',
  'eleve-transfert': 'Transfert / Radiation / Abandon',
  'eleve-archives': 'Archives',
  'classes': 'Classes',
  'classe-creer': 'Créer une classe',
  'classe-liste': 'Liste des classes',
  'classe-affecter-eleves': 'Affecter élèves',
  'classe-affecter-enseignants': 'Affecter enseignants',
  'personnel': 'Personnel',
  'personnel-ajouter': 'Ajouter un personnel',
  'personnel-liste': 'Liste du personnel',
  'personnel-dossier': 'Dossier personnel',
  'personnel-affectation': 'Affectation par classe',
  'personnel-transfert': 'Transfert / Radiation / Abandon',
  'personnel-archives': 'Archives',
  'notes': 'Notes',
  'bulletins': 'Bulletins',
  'presences': 'Présences',
  'emploi-du-temps': 'Emploi du Temps',
  'parametres': 'Paramètres',
};

const viewColors: Record<string, string> = {
  'eleve-ajouter': 'bg-emerald-100 text-emerald-700',
  'eleve-liste': 'bg-blue-100 text-blue-700',
  'eleve-dossier': 'bg-amber-100 text-amber-700',
  'eleve-affectation': 'bg-purple-100 text-purple-700',
  'eleve-transfert': 'bg-red-100 text-red-700',
  'eleve-archives': 'bg-slate-200 text-slate-700',
  'classe-creer': 'bg-emerald-100 text-emerald-700',
  'classe-liste': 'bg-blue-100 text-blue-700',
  'classe-affecter-eleves': 'bg-purple-100 text-purple-700',
  'classe-affecter-enseignants': 'bg-amber-100 text-amber-700',
  'personnel-ajouter': 'bg-emerald-100 text-emerald-700',
  'personnel-liste': 'bg-blue-100 text-blue-700',
  'personnel-dossier': 'bg-amber-100 text-amber-700',
  'personnel-affectation': 'bg-purple-100 text-purple-700',
  'personnel-transfert': 'bg-red-100 text-red-700',
  'personnel-archives': 'bg-slate-200 text-slate-700',
};

export default function Home() {
  const [activeView, setActiveView] = useState<ViewType>('dashboard');
  const [mounted, setMounted] = useState(false);
  const parametres = useAppStore((s) => s.parametres);

  useEffect(() => {
    setMounted(true);
  }, []);

  const renderView = () => {
    switch (activeView) {
      case 'dashboard':
        return <DashboardView onNavigate={setActiveView} />;
      case 'eleves':
      case 'eleve-ajouter':
      case 'eleve-liste':
      case 'eleve-dossier':
      case 'eleve-affectation':
      case 'eleve-transfert':
      case 'eleve-archives':
        return <ElevesView />;
      case 'classes':
      case 'classe-creer':
      case 'classe-liste':
      case 'classe-affecter-eleves':
      case 'classe-affecter-enseignants':
        return <ClassesView />;
      case 'personnel':
      case 'personnel-ajouter':
      case 'personnel-liste':
      case 'personnel-dossier':
      case 'personnel-affectation':
      case 'personnel-transfert':
      case 'personnel-archives':
        return <ElevesView />; // Placeholder until personnel views are created
      case 'notes':
        return <NotesView />;
      case 'bulletins':
        return <BulletinsView />;
      case 'presences':
        return <PresencesView />;
      case 'emploi-du-temps':
        return <EmploiDuTempsView />;
      case 'parametres':
        return <ParametresView />;
      default:
        return <DashboardView onNavigate={setActiveView} />;
    }
  };

  return (
    <SidebarProvider>
      <AppSidebar activeView={activeView} onViewChange={setActiveView} />
      <SidebarInset>
        <header className="flex h-14 shrink-0 items-center gap-2 border-b px-4">
          <SidebarTrigger className="-ml-1" />
          <Separator orientation="vertical" className="mr-2 !h-4" />
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-medium">{viewLabels[activeView]}</h2>
            {mounted && parametres.cyclesActifs?.map((cycle) => (
              <span key={cycle} className="hidden sm:inline-flex items-center rounded-md bg-emerald-100 px-2 py-0.5 text-[10px] font-medium text-emerald-700">
                {cycle}
              </span>
            ))}
            {viewColors[activeView] && (
              <span className={`hidden sm:inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-medium ${viewColors[activeView]}`}>
                {viewLabels[activeView]}
              </span>
            )}
          </div>
          <div className="ml-auto text-xs text-muted-foreground hidden sm:block">
            {mounted ? parametres.anneeScolaire : ''}
          </div>
        </header>
        <main className="flex-1 overflow-auto p-4 md:p-6">
          {!mounted ? (
            <div className="flex items-center justify-center h-64">
              <div className="flex flex-col items-center gap-3">
                <div className="h-8 w-8 animate-spin rounded-full border-4 border-emerald-200 border-t-emerald-600" />
                <p className="text-sm text-muted-foreground">Chargement des données...</p>
              </div>
            </div>
          ) : (
            renderView()
          )}
        </main>
      </SidebarInset>
    </SidebarProvider>
  );
}
