'use client';

import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import type { ViewType } from '@/lib/types';
import {
  LayoutDashboard, Users, GraduationCap, BookOpen,
  FileText, ClipboardCheck, CalendarDays, Settings,
  School, UserPlus, List, FolderOpen, ArrowRightLeft, XCircle,
  ChevronDown, Archive, PlusCircle, UsersRound, UserCog, Briefcase,
} from 'lucide-react';
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent,
  SidebarGroupLabel, SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem,
  SidebarMenuSub, SidebarMenuSubButton, SidebarMenuSubItem,
  SidebarFooter, SidebarRail,
} from '@/components/ui/sidebar';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';

const mainMenuItems: { id: ViewType; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'dashboard', label: 'Tableau de Bord', icon: LayoutDashboard },
  { id: 'notes', label: 'Notes', icon: BookOpen },
  { id: 'bulletins', label: 'Bulletins', icon: FileText },
  { id: 'presences', label: 'Présences', icon: ClipboardCheck },
  { id: 'emploi-du-temps', label: 'Emploi du Temps', icon: CalendarDays },
  { id: 'parametres', label: 'Paramètres', icon: Settings },
];

const eleveSubMenus: { id: ViewType; label: string; icon: React.ComponentType<{ className?: string }>; color: string }[] = [
  { id: 'eleve-ajouter', label: 'Ajouter un élève', icon: UserPlus, color: 'text-emerald-600' },
  { id: 'eleve-liste', label: 'Liste des élèves', icon: List, color: 'text-blue-600' },
  { id: 'eleve-dossier', label: 'Dossier élève', icon: FolderOpen, color: 'text-amber-600' },
  { id: 'eleve-affectation', label: 'Affectation par classe', icon: GraduationCap, color: 'text-purple-600' },
  { id: 'eleve-transfert', label: 'Transfert / Radiation / Abandon', icon: ArrowRightLeft, color: 'text-red-600' },
  { id: 'eleve-archives', label: 'Archives', icon: Archive, color: 'text-slate-600' },
];

const classeSubMenus: { id: ViewType; label: string; icon: React.ComponentType<{ className?: string }>; color: string }[] = [
  { id: 'classe-creer', label: 'Créer une classe', icon: PlusCircle, color: 'text-emerald-600' },
  { id: 'classe-liste', label: 'Liste des classes', icon: List, color: 'text-blue-600' },
  { id: 'classe-affecter-eleves', label: 'Affecter élèves', icon: UsersRound, color: 'text-purple-600' },
  { id: 'classe-affecter-enseignants', label: 'Affecter enseignants', icon: UserCog, color: 'text-amber-600' },
];

const personnelSubMenus: { id: ViewType; label: string; icon: React.ComponentType<{ className?: string }>; color: string }[] = [
  { id: 'personnel-ajouter', label: 'Ajouter un personnel', icon: UserPlus, color: 'text-emerald-600' },
  { id: 'personnel-liste', label: 'Liste du personnel', icon: List, color: 'text-blue-600' },
  { id: 'personnel-dossier', label: 'Dossier personnel', icon: FolderOpen, color: 'text-amber-600' },
  { id: 'personnel-affectation', label: 'Affectation par classe', icon: GraduationCap, color: 'text-purple-600' },
  { id: 'personnel-transfert', label: 'Transfert / Radiation / Abandon', icon: ArrowRightLeft, color: 'text-red-600' },
  { id: 'personnel-archives', label: 'Archives', icon: Archive, color: 'text-slate-600' },
];

const eleveParentViews: ViewType[] = ['eleves', ...eleveSubMenus.map(s => s.id)];
const classeParentViews: ViewType[] = ['classes', ...classeSubMenus.map(s => s.id)];
const personnelParentViews: ViewType[] = ['personnel', ...personnelSubMenus.map(s => s.id)];

interface AppSidebarProps {
  activeView: ViewType;
  onViewChange: (view: ViewType) => void;
}

export function AppSidebar({ activeView, onViewChange }: AppSidebarProps) {
  const parametres = useAppStore((s) => s.parametres);
  const [eleveOpen, setEleveOpen] = useState(eleveParentViews.includes(activeView));
  const [classeOpen, setClasseOpen] = useState(classeParentViews.includes(activeView));
  const [personnelOpen, setPersonnelOpen] = useState(personnelParentViews.includes(activeView));

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-2">
          <School className="h-6 w-6 text-emerald-600 shrink-0" />
          <span className="font-bold text-sm leading-tight truncate">
            {parametres.nomEcole}
          </span>
        </div>
        <p className="text-xs text-muted-foreground truncate">
          {parametres.anneeScolaire}
        </p>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {/* Dashboard */}
              <SidebarMenuItem>
                <SidebarMenuButton
                  isActive={activeView === 'dashboard'}
                  onClick={() => onViewChange('dashboard')}
                  tooltip="Tableau de Bord"
                >
                  <LayoutDashboard className="h-4 w-4" />
                  <span>Tableau de Bord</span>
                </SidebarMenuButton>
              </SidebarMenuItem>

              {/* Classes - Collapsible with sub-menus */}
              <Collapsible open={classeOpen} onOpenChange={setClasseOpen}>
                <SidebarMenuItem>
                  <CollapsibleTrigger asChild>
                    <SidebarMenuButton
                      isActive={classeParentViews.includes(activeView)}
                      tooltip="Classes"
                    >
                      <GraduationCap className="h-4 w-4" />
                      <span>Classes</span>
                      <ChevronDown className={`ml-auto h-4 w-4 transition-transform ${classeOpen ? 'rotate-180' : ''}`} />
                    </SidebarMenuButton>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <SidebarMenuSub>
                      {classeSubMenus.map((sub) => (
                        <SidebarMenuSubItem key={sub.id}>
                          <SidebarMenuSubButton
                            isActive={activeView === sub.id}
                            onClick={() => onViewChange(sub.id)}
                          >
                            <sub.icon className={`h-4 w-4 ${sub.color}`} />
                            <span>{sub.label}</span>
                          </SidebarMenuSubButton>
                        </SidebarMenuSubItem>
                      ))}
                    </SidebarMenuSub>
                  </CollapsibleContent>
                </SidebarMenuItem>
              </Collapsible>

              {/* Élèves - Collapsible with sub-menus */}
              <Collapsible open={eleveOpen} onOpenChange={setEleveOpen}>
                <SidebarMenuItem>
                  <CollapsibleTrigger asChild>
                    <SidebarMenuButton
                      isActive={eleveParentViews.includes(activeView)}
                      tooltip="Élèves"
                    >
                      <Users className="h-4 w-4" />
                      <span>Élèves</span>
                      <ChevronDown className={`ml-auto h-4 w-4 transition-transform ${eleveOpen ? 'rotate-180' : ''}`} />
                    </SidebarMenuButton>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <SidebarMenuSub>
                      {eleveSubMenus.map((sub) => (
                        <SidebarMenuSubItem key={sub.id}>
                          <SidebarMenuSubButton
                            isActive={activeView === sub.id}
                            onClick={() => onViewChange(sub.id)}
                          >
                            <sub.icon className={`h-4 w-4 ${sub.color}`} />
                            <span>{sub.label}</span>
                          </SidebarMenuSubButton>
                        </SidebarMenuSubItem>
                      ))}
                    </SidebarMenuSub>
                  </CollapsibleContent>
                </SidebarMenuItem>
              </Collapsible>

              {/* Personnel - Collapsible with sub-menus */}
              <Collapsible open={personnelOpen} onOpenChange={setPersonnelOpen}>
                <SidebarMenuItem>
                  <CollapsibleTrigger asChild>
                    <SidebarMenuButton
                      isActive={personnelParentViews.includes(activeView)}
                      tooltip="Personnel"
                    >
                      <Briefcase className="h-4 w-4" />
                      <span>Personnel</span>
                      <ChevronDown className={`ml-auto h-4 w-4 transition-transform ${personnelOpen ? 'rotate-180' : ''}`} />
                    </SidebarMenuButton>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <SidebarMenuSub>
                      {personnelSubMenus.map((sub) => (
                        <SidebarMenuSubItem key={sub.id}>
                          <SidebarMenuSubButton
                            isActive={activeView === sub.id}
                            onClick={() => onViewChange(sub.id)}
                          >
                            <sub.icon className={`h-4 w-4 ${sub.color}`} />
                            <span>{sub.label}</span>
                          </SidebarMenuSubButton>
                        </SidebarMenuSubItem>
                      ))}
                    </SidebarMenuSub>
                  </CollapsibleContent>
                </SidebarMenuItem>
              </Collapsible>

              {/* Other menu items */}
              {mainMenuItems
                .filter(item => item.id !== 'dashboard')
                .map((item) => (
                  <SidebarMenuItem key={item.id}>
                    <SidebarMenuButton
                      isActive={activeView === item.id}
                      onClick={() => onViewChange(item.id)}
                      tooltip={item.label}
                    >
                      <item.icon className="h-4 w-4" />
                      <span>{item.label}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <div className="h-2 w-2 rounded-full bg-emerald-500" />
          <span>En ligne — Sénégal</span>
        </div>
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  );
}
