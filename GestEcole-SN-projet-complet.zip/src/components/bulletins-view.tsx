'use client';

import { useState, useMemo } from 'react';
import { useAppStore } from '@/lib/store';
import type { Periode } from '@/lib/types';
import { MATIERES, getPeriodesForCycle, getPeriodeLabel } from '@/lib/types';
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  FileText, Printer, Download, Award,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function BulletinsView() {
  const eleves = useAppStore((s) => s.eleves);
  const classes = useAppStore((s) => s.classes);
  const notes = useAppStore((s) => s.notes);
  const bulletins = useAppStore((s) => s.bulletins);
  const parametres = useAppStore((s) => s.parametres);
  const { updateBulletin } = useAppStore();
  const { toast } = useToast();

  const cycleClasses = classes.filter((c) => parametres.cyclesActifs.includes(c.cycle));
  const cycleEleves = eleves.filter((e) => parametres.cyclesActifs.includes(e.cycle) && e.statut === 'actif');

  const selectedEleve = cycleEleves.find((e) => e.id === selectedEleveId);
  const selectedEleveClasse = selectedEleve ? classes.find((c) => c.id === selectedEleve.classeId) : undefined;
  const selectedEleveCycle = selectedEleveClasse?.cycle || parametres.cyclesActifs[0];
  const matieres = MATIERES[selectedEleveCycle] || [];
  const periodesDisponibles = getPeriodesForCycle(selectedEleveCycle);

  const [selectedEleveId, setSelectedEleveId] = useState<string>('');
  const [selectedPeriode, setSelectedPeriode] = useState<Periode>('T1');

  // Derive effective periode - reset if not available for the current cycle
  const effectivePeriode = periodesDisponibles.includes(selectedPeriode)
    ? selectedPeriode
    : periodesDisponibles[0];
  const [previewOpen, setPreviewOpen] = useState(false);
  const [editAppreciation, setEditAppreciation] = useState('');

  const filteredEleves = useMemo(() => {
    if (!selectedEleveId) return [];
    return cycleEleves.filter((e) => e.id === selectedEleveId);
  }, [cycleEleves, selectedEleveId]);

  const eleveNotes = useMemo(() => {
    if (!selectedEleveId) return [];
    return notes.filter((n) => n.eleveId === selectedEleveId && n.periode === effectivePeriode);
  }, [notes, selectedEleveId, effectivePeriode]);

  const bulletin = useMemo(() => {
    if (!selectedEleveId) return undefined;
    return bulletins.find((b) => b.eleveId === selectedEleveId && b.periode === effectivePeriode);
  }, [bulletins, selectedEleveId, effectivePeriode]);

  const generateBulletinData = () => {
    if (!selectedEleveId) return null;
    const eleve = cycleEleves.find((e) => e.id === selectedEleveId);
    if (!eleve) return null;

    const classe = classes.find((c) => c.id === eleve.classeId);
    const eNotes = notes.filter((n) => n.eleveId === selectedEleveId && n.periode === effectivePeriode);

    let totalPondere = 0;
    let totalCoef = 0;
    const matieresData = matieres.map((matiere) => {
      const mNotes = eNotes.filter((n) => n.matiere === matiere);
      if (mNotes.length === 0) return { matiere, note: '-', coef: '-', moyenne: '-' };
      const sum = mNotes.reduce((acc, n) => acc + n.note, 0);
      const avg = sum / mNotes.length;
      const coef = mNotes[0].coefficient;
      totalPondere += avg * coef;
      totalCoef += coef;
      return { matiere, note: avg.toFixed(1), coef, moyenne: (avg * coef).toFixed(2) };
    });

    const moyenneGen = totalCoef > 0 ? (totalPondere / totalCoef).toFixed(2) : '-';
    const mention = moyenneGen !== '-' ? (
      Number(moyenneGen) >= 16 ? 'Excellent' :
      Number(moyenneGen) >= 14 ? 'Très Bien' :
      Number(moyenneGen) >= 12 ? 'Bien' :
      Number(moyenneGen) >= 10 ? 'Assez Bien' :
      Number(moyenneGen) >= 8 ? 'Passable' : 'Insuffisant'
    ) : '-';

    return { eleve, classe, matieresData, moyenneGen, mention, appreciation: bulletin?.appreciation || '' };
  };

  const bulletinData = generateBulletinData();

  const handlePreview = () => {
    if (!selectedEleveId) {
      toast({ title: 'Erreur', description: 'Veuillez sélectionner un élève.', variant: 'destructive' });
      return;
    }
    if (bulletin) setEditAppreciation(bulletin.appreciation);
    setPreviewOpen(true);
  };

  const handleSaveAppreciation = () => {
    if (bulletin) {
      updateBulletin(bulletin.id, { appreciation: editAppreciation });
      toast({ title: 'Appréciation mise à jour' });
    }
    setPreviewOpen(false);
  };

  const handlePrint = () => {
    window.print();
  };

  const getNoteColor = (note: string) => {
    const num = parseFloat(note);
    if (num >= 14) return 'text-emerald-600 font-semibold';
    if (num >= 10) return 'text-blue-600';
    if (num >= 8) return 'text-amber-600';
    return 'text-red-600 font-semibold';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Bulletins</h1>
          <p className="text-muted-foreground">Génération et visualisation des bulletins de notes</p>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="space-y-2 flex-1">
              <Label>Élève</Label>
              <Select value={selectedEleveId} onValueChange={setSelectedEleveId}>
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionnez un élève" />
                </SelectTrigger>
                <SelectContent>
                  {cycleEleves.map((e) => {
                    const classe = classes.find((c) => c.id === e.classeId);
                    return (
                      <SelectItem key={e.id} value={e.id}>
                        {e.nom} {e.prenom} — {classe?.niveau}
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 w-full sm:w-48">
              <Label>Période</Label>
              <Select value={effectivePeriode} onValueChange={(v) => setSelectedPeriode(v as Periode)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {periodesDisponibles.map((p) => (
                    <SelectItem key={p} value={p}>{getPeriodeLabel(p)}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end gap-2">
              <Button onClick={handlePreview} className="gap-2 bg-emerald-600 hover:bg-emerald-700">
                <FileText className="h-4 w-4" />
                Voir le bulletin
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Preview bulletin content inline */}
      {bulletinData && (
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <CardTitle>Bulletin de {bulletinData.eleve.prenom} {bulletinData.eleve.nom}</CardTitle>
                <CardDescription>
                  {bulletinData.classe?.nom} — {getPeriodeLabel(effectivePeriode)} — {parametres.anneeScolaire}
                </CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="gap-1" onClick={handlePrint}>
                  <Printer className="h-3 w-3" />
                  Imprimer
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* School Info */}
            <div className="text-center space-y-1">
              <h2 className="text-lg font-bold text-emerald-700">{parametres.nomEcole}</h2>
              <p className="text-sm text-muted-foreground">{parametres.adresse}</p>
              <p className="text-sm text-muted-foreground">Tél: {parametres.telephone}</p>
              <Separator className="my-3" />
              <h3 className="text-base font-semibold">
                BULLETIN DE NOTES — {getPeriodeLabel(effectivePeriode).toUpperCase()}
              </h3>
            </div>

            {/* Student Info */}
            <div className="grid grid-cols-2 gap-4 text-sm bg-muted/50 p-4 rounded-lg">
              <div>
                <span className="text-muted-foreground">Élève : </span>
                <span className="font-semibold">{bulletinData.eleve.nom} {bulletinData.eleve.prenom}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Classe : </span>
                <span className="font-semibold">{bulletinData.classe?.niveau}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Date de naissance : </span>
                <span className="font-semibold">{new Date(bulletinData.eleve.dateNaissance).toLocaleDateString('fr-FR')}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Sexe : </span>
                <span className="font-semibold">{bulletinData.eleve.sexe === 'M' ? 'Masculin' : 'Féminin'}</span>
              </div>
            </div>

            {/* Grades Table */}
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Matière</TableHead>
                  <TableHead className="text-center">Note /20</TableHead>
                  <TableHead className="text-center">Coefficient</TableHead>
                  <TableHead className="text-center">Note pondérée</TableHead>
                  <TableHead className="text-center">Appréciation</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bulletinData.matieresData.map((m) => (
                  <TableRow key={m.matiere}>
                    <TableCell className="font-medium">{m.matiere}</TableCell>
                    <TableCell className={`text-center ${m.note !== '-' ? getNoteColor(m.note) : ''}`}>
                      {m.note !== '-' ? m.note : 'N/A'}
                    </TableCell>
                    <TableCell className="text-center">{m.coef}</TableCell>
                    <TableCell className="text-center font-medium">{m.moyenne !== '-' ? m.moyenne : 'N/A'}</TableCell>
                    <TableCell className="text-center text-sm">
                      {m.note !== '-' ? (
                        parseFloat(m.note) >= 14 ? 'Excellent' :
                        parseFloat(m.note) >= 12 ? 'Bien' :
                        parseFloat(m.note) >= 10 ? 'Assez Bien' :
                        parseFloat(m.note) >= 8 ? 'Passable' : 'Insuffisant'
                      ) : ''}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {/* Summary */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card className="bg-emerald-50 border-emerald-200">
                <CardContent className="pt-4 text-center">
                  <p className="text-sm text-muted-foreground">Moyenne Générale</p>
                  <p className="text-2xl font-bold text-emerald-700">{bulletinData.moyenneGen}/20</p>
                </CardContent>
              </Card>
              <Card className="bg-amber-50 border-amber-200">
                <CardContent className="pt-4 text-center">
                  <p className="text-sm text-muted-foreground">Mention</p>
                  <p className="text-2xl font-bold text-amber-700">{bulletinData.mention}</p>
                </CardContent>
              </Card>
              <Card className="bg-blue-50 border-blue-200">
                <CardContent className="pt-4 text-center">
                  <p className="text-sm text-muted-foreground">Rang</p>
                  <p className="text-2xl font-bold text-blue-700">{bulletin?.rang || '-'}/{bulletinData.classe?.effectif || '-'}</p>
                </CardContent>
              </Card>
            </div>

            {/* Appreciation */}
            <div className="space-y-2">
              <Label>Appréciation du conseil de classe</Label>
              <Input
                value={bulletinData.appreciation}
                onChange={(e) => {
                  if (bulletin) {
                    updateBulletin(bulletin.id, { appreciation: e.target.value });
                  }
                }}
                placeholder="Appréciation générale..."
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Preview Dialog */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Aperçu du bulletin</DialogTitle>
          </DialogHeader>
          {bulletinData && (
            <div className="space-y-4">
              <div className="text-center space-y-1">
                <h2 className="text-lg font-bold text-emerald-700">{parametres.nomEcole}</h2>
                <p className="text-sm text-muted-foreground">{parametres.adresse}</p>
                <Separator className="my-3" />
                <h3 className="text-base font-semibold">
                  BULLETIN DE NOTES — {getPeriodeLabel(effectivePeriode).toUpperCase()}
                </h3>
              </div>
              <div className="bg-muted/50 p-4 rounded-lg text-sm space-y-1">
                <p><strong>Élève :</strong> {bulletinData.eleve.nom} {bulletinData.eleve.prenom}</p>
                <p><strong>Classe :</strong> {bulletinData.classe?.niveau}</p>
                <p><strong>Moyenne :</strong> {bulletinData.moyenneGen}/20 — <strong>Mention :</strong> {bulletinData.mention}</p>
              </div>
              <div className="space-y-2">
                <Label>Appréciation</Label>
                <Input
                  value={editAppreciation}
                  onChange={(e) => setEditAppreciation(e.target.value)}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setPreviewOpen(false)}>Fermer</Button>
            <Button onClick={handleSaveAppreciation} className="bg-emerald-600 hover:bg-emerald-700">
              Enregistrer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
