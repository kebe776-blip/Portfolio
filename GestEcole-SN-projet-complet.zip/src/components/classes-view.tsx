'use client';

import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import type { Classe, CycleType } from '@/lib/types';
import { CYCLE_NIVEAUX } from '@/lib/types';
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Plus, Pencil, Trash2, GraduationCap } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function ClassesView() {
  const classes = useAppStore((s) => s.classes);
  const parametres = useAppStore((s) => s.parametres);
  const { addClasse, updateClasse, deleteClasse } = useAppStore();
  const { toast } = useToast();

  const cycleClasses = classes.filter((c) => parametres.cyclesActifs.includes(c.cycle));

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingClasse, setEditingClasse] = useState<Classe | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    nom: '',
    niveau: '',
    cycle: parametres.cyclesActifs[0] as CycleType,
    capacite: 40,
    anneeScolaire: parametres.anneeScolaire,
  });

  const openAddDialog = () => {
    setEditingClasse(null);
    setFormData({
      nom: '',
      niveau: '',
      cycle: parametres.cyclesActifs[0] as CycleType,
      capacite: 40,
      anneeScolaire: parametres.anneeScolaire,
    });
    setDialogOpen(true);
  };

  const openEditDialog = (classe: Classe) => {
    setEditingClasse(classe);
    setFormData({
      nom: classe.nom,
      niveau: classe.niveau,
      cycle: classe.cycle,
      capacite: classe.capacite,
      anneeScolaire: classe.anneeScolaire,
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.nom || !formData.niveau) {
      toast({ title: 'Erreur', description: 'Veuillez remplir tous les champs obligatoires.', variant: 'destructive' });
      return;
    }
    if (editingClasse) {
      updateClasse(editingClasse.id, { ...formData });
      toast({ title: 'Classe modifiée', description: `La classe ${formData.nom} a été mise à jour.` });
    } else {
      addClasse({ ...formData, effectif: 0 });
      toast({ title: 'Classe ajoutée', description: `La classe ${formData.nom} a été créée.` });
    }
    setDialogOpen(false);
  };

  const handleDelete = (id: string) => {
    setDeleteId(id);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (deleteId) {
      const classe = classes.find(c => c.id === deleteId);
      deleteClasse(deleteId);
      toast({ title: 'Classe supprimée', description: `La classe ${classe?.nom} a été supprimée.` });
    }
    setDeleteDialogOpen(false);
    setDeleteId(null);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Classes</h1>
          <p className="text-muted-foreground">
            Gestion des classes — Cycles {parametres.cyclesActifs.join(', ')} ({cycleClasses.length} classes)
          </p>
        </div>
        <Button onClick={openAddDialog} className="gap-2">
          <Plus className="h-4 w-4" />
          Ajouter une classe
        </Button>
      </div>

      {/* Classes Grid */}
      {cycleClasses.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <GraduationCap className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium">Aucune classe</p>
            <p className="text-sm text-muted-foreground">
              Ajoutez des classes pour les cycles actifs
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {cycleClasses.map((classe) => (
            <Card key={classe.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-emerald-100 flex items-center justify-center">
                      <GraduationCap className="h-5 w-5 text-emerald-700" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{classe.nom}</CardTitle>
                      <CardDescription>{classe.niveau}</CardDescription>
                    </div>
                  </div>
                  <Badge variant="outline">{classe.cycle}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3 text-sm mb-4">
                  <div>
                    <p className="text-muted-foreground">Effectif</p>
                    <p className="font-semibold">{classe.effectif}/{classe.capacite}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Année</p>
                    <p className="font-semibold">{classe.anneeScolaire}</p>
                  </div>
                </div>
                <div className="h-1.5 bg-muted rounded-full overflow-hidden mb-4">
                  <div
                    className="h-full bg-emerald-500 rounded-full transition-all"
                    style={{ width: `${Math.min(100, (classe.effectif / classe.capacite) * 100)}%` }}
                  />
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1 gap-1" onClick={() => openEditDialog(classe)}>
                    <Pencil className="h-3 w-3" />
                    Modifier
                  </Button>
                  <Button variant="outline" size="sm" className="gap-1 text-destructive hover:text-destructive" onClick={() => handleDelete(classe.id)}>
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingClasse ? 'Modifier la classe' : 'Ajouter une classe'}</DialogTitle>
            <DialogDescription>
              {editingClasse ? 'Modifiez les informations de la classe.' : 'Remplissez les informations pour créer une nouvelle classe.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Nom de la classe *</Label>
              <Input
                placeholder="Ex: Classe de CP1"
                value={formData.nom}
                onChange={(e) => setFormData({ ...formData, nom: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Cycle *</Label>
              <Select value={formData.cycle} onValueChange={(v) => setFormData({ ...formData, cycle: v as CycleType, niveau: '' })}>
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionnez un cycle" />
                </SelectTrigger>
                <SelectContent>
                  {parametres.cyclesActifs.map((cycle) => (
                    <SelectItem key={cycle} value={cycle}>{cycle}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Niveau *</Label>
              <Select value={formData.niveau} onValueChange={(v) => setFormData({ ...formData, niveau: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionnez un niveau" />
                </SelectTrigger>
                <SelectContent>
                  {CYCLE_NIVEAUX[formData.cycle]?.map((niveau) => (
                    <SelectItem key={niveau} value={niveau}>{niveau}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Capacité</Label>
              <Input
                type="number"
                min={1}
                value={formData.capacite}
                onChange={(e) => setFormData({ ...formData, capacite: parseInt(e.target.value) || 0 })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">
              {editingClasse ? 'Enregistrer' : 'Ajouter'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirmer la suppression</DialogTitle>
            <DialogDescription>
              Êtes-vous sûr de vouloir supprimer cette classe ? Les élèves associés seront marqués comme inactifs.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>Annuler</Button>
            <Button variant="destructive" onClick={confirmDelete}>Supprimer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
