'use client';

import { useAppStore } from '@/lib/store';
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Users, GraduationCap, BookOpen, ClipboardCheck,
  TrendingUp, TrendingDown, UserPlus, FileText,
  CalendarDays, ArrowRight, Briefcase,
} from 'lucide-react';
import type { ViewType } from '@/lib/types';

interface DashboardViewProps {
  onNavigate: (view: ViewType) => void;
}

export function DashboardView({ onNavigate }: DashboardViewProps) {
  const eleves = useAppStore((s) => s.eleves);
  const classes = useAppStore((s) => s.classes);
  const notes = useAppStore((s) => s.notes);
  const presences = useAppStore((s) => s.presences);
  const personnels = useAppStore((s) => s.personnels);
  const parametres = useAppStore((s) => s.parametres);

  // Filter by active cycles
  const cycleClasses = classes.filter((c) => parametres.cyclesActifs.includes(c.cycle));
  const cycleEleves = eleves.filter((e) => parametres.cyclesActifs.includes(e.cycle) && e.statut === 'actif');
  const actifPersonnels = personnels.filter((p) => p.statut === 'actif');

  // Calculate average
  const cycleEleveIds = cycleEleves.map((e) => e.id);
  const cycleNotes = notes.filter((n) => cycleEleveIds.includes(n.eleveId));
  let totalPondere = 0;
  let totalCoef = 0;
  cycleNotes.forEach((n) => {
    totalPondere += n.note * n.coefficient;
    totalCoef += n.coefficient;
  });
  const moyenneGen = totalCoef > 0 ? Math.round((totalPondere / totalCoef) * 100) / 100 : 0;

  // Calculate attendance rate
  const cyclePresences = presences.filter((p) => cycleEleveIds.includes(p.eleveId));
  const presentCount = cyclePresences.filter((p) => p.statut === 'present').length;
  const totalPresence = cyclePresences.length;
  const tauxPresence = totalPresence > 0 ? Math.round((presentCount / totalPresence) * 100) : 0;

  // Recent students
  const recentEleves = cycleEleves.slice(-5).reverse();

  // Class distribution
  const classDistribution = cycleClasses.map((c) => ({
    nom: c.nom,
    effectif: c.effectif,
  }));

  const cyclesLabel = parametres.cyclesActifs.join(', ');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Tableau de Bord</h1>
        <p className="text-muted-foreground">
          Vue d&apos;ensemble de {parametres.nomEcole} — {cyclesLabel}
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-emerald-200 bg-gradient-to-br from-emerald-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Élèves</CardTitle>
            <Users className="h-4 w-4 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-700">{cycleEleves.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {cycleClasses.length} classe{cycleClasses.length > 1 ? 's' : ''}
            </p>
          </CardContent>
        </Card>

        <Card className="border-amber-200 bg-gradient-to-br from-amber-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Classes</CardTitle>
            <GraduationCap className="h-4 w-4 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-700">{cycleClasses.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {cyclesLabel}
            </p>
          </CardContent>
        </Card>

        <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Moyenne Générale</CardTitle>
            <BookOpen className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-700">{moyenneGen.toFixed(1)}/20</div>
            <div className="flex items-center gap-1 mt-1">
              {moyenneGen >= 10 ? (
                <TrendingUp className="h-3 w-3 text-emerald-600" />
              ) : (
                <TrendingDown className="h-3 w-3 text-red-600" />
              )}
              <p className="text-xs text-muted-foreground">
                {moyenneGen >= 10 ? 'Au-dessus de la moyenne' : 'En dessous de la moyenne'}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-white">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Personnel actif</CardTitle>
            <Briefcase className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-700">{actifPersonnels.length}</div>
            <div className="flex items-center gap-1 mt-1">
              <ClipboardCheck className="h-3 w-3 text-emerald-600" />
              <p className="text-xs text-muted-foreground">
                Présences: {tauxPresence}%
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Actions Rapides</CardTitle>
            <CardDescription>Accès direct aux fonctionnalités</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button variant="outline" className="w-full justify-between" onClick={() => onNavigate('eleve-ajouter')}>
              <span className="flex items-center gap-2">
                <UserPlus className="h-4 w-4" />
                Ajouter un élève
              </span>
              <ArrowRight className="h-4 w-4" />
            </Button>
            <Button variant="outline" className="w-full justify-between" onClick={() => onNavigate('notes')}>
              <span className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                Saisir des notes
              </span>
              <ArrowRight className="h-4 w-4" />
            </Button>
            <Button variant="outline" className="w-full justify-between" onClick={() => onNavigate('bulletins')}>
              <span className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Générer un bulletin
              </span>
              <ArrowRight className="h-4 w-4" />
            </Button>
            <Button variant="outline" className="w-full justify-between" onClick={() => onNavigate('presences')}>
              <span className="flex items-center gap-2">
                <ClipboardCheck className="h-4 w-4" />
                Appel du jour
              </span>
              <ArrowRight className="h-4 w-4" />
            </Button>
            <Button variant="outline" className="w-full justify-between" onClick={() => onNavigate('emploi-du-temps')}>
              <span className="flex items-center gap-2">
                <CalendarDays className="h-4 w-4" />
                Emploi du temps
              </span>
              <ArrowRight className="h-4 w-4" />
            </Button>
          </CardContent>
        </Card>

        {/* Class Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Répartition par Classe</CardTitle>
            <CardDescription>Effectifs par classe</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {classDistribution.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">Aucune classe</p>
            ) : (
              classDistribution.map((classe) => {
                const maxEffectif = Math.max(...classDistribution.map((c) => c.effectif), 1);
                const pct = Math.round((classe.effectif / maxEffectif) * 100);
                return (
                  <div key={classe.nom} className="space-y-1">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium">{classe.nom}</span>
                      <Badge variant="secondary" className="text-xs">{classe.effectif}</Badge>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-500 rounded-full transition-all"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </CardContent>
        </Card>

        {/* Recent Students */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Élèves Récents</CardTitle>
            <CardDescription>Derniers élèves inscrits</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentEleves.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">Aucun élève</p>
            ) : (
              recentEleves.map((eleve) => {
                const classe = classes.find((c) => c.id === eleve.classeId);
                return (
                  <div key={eleve.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`h-8 w-8 rounded-full flex items-center justify-center text-xs font-bold ${
                        eleve.sexe === 'M' ? 'bg-blue-100 text-blue-700' : 'bg-pink-100 text-pink-700'
                      }`}>
                        {eleve.prenom[0]}{eleve.nom[0]}
                      </div>
                      <div>
                        <p className="text-sm font-medium">{eleve.prenom} {eleve.nom}</p>
                        <p className="text-xs text-muted-foreground">{classe?.niveau || 'N/A'}</p>
                      </div>
                    </div>
                    <Badge variant={eleve.statut === 'actif' ? 'default' : 'secondary'} className="text-xs">
                      {eleve.statut === 'actif' ? 'Actif' : 'Inactif'}
                    </Badge>
                  </div>
                );
              })
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
