'use client';

import { useState, useMemo } from 'react';
import { useAppStore } from '@/lib/store';
import type { Eleve } from '@/lib/types';
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Plus, Pencil, Trash2, Search, Users, Eye,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function ElevesView() {
  const eleves = useAppStore((s) => s.eleves);
  const classes = useAppStore((s) => s.classes);
  const parametres = useAppStore((s) => s.parametres);
  const { addEleve, updateEleve, deleteEleve } = useAppStore();
  const { toast } = useToast();

  const cycleClasses = classes.filter((c) => parametres.cyclesActifs.includes(c.cycle));
  const cycleEleves = eleves.filter((e) => parametres.cyclesActifs.includes(e.cycle));

  const [search, setSearch] = useState('');
  const [filterClasse, setFilterClasse] = useState<string>('all');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingEleve, setEditingEleve] = useState<Eleve | null>(null);
  const [selectedEleve, setSelectedEleve] = useState<Eleve | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    nom: '', prenom: '', dateNaissance: '', sexe: 'M' as 'M' | 'F',
    classeId: '', parentContact: '', adresse: '',
  });

  const filteredEleves = useMemo(() => {
    let result = cycleEleves;
    if (filterClasse !== 'all') {
      result = result.filter((e) => e.classeId === filterClasse);
    }
    if (search) {
      const q = search.toLowerCase();
      result = result.filter((e) =>
        `${e.nom} ${e.prenom}`.toLowerCase().includes(q)
      );
    }
    return result;
  }, [cycleEleves, filterClasse, search]);

  const openAddDialog = () => {
    setEditingEleve(null);
    setFormData({
      nom: '', prenom: '', dateNaissance: '', sexe: 'M' as 'M' | 'F',
      classeId: cycleClasses[0]?.id || '', parentContact: '', adresse: '',
    });
    setDialogOpen(true);
  };

  const openEditDialog = (eleve: Eleve) => {
    setEditingEleve(eleve);
    setFormData({
      nom: eleve.nom, prenom: eleve.prenom, dateNaissance: eleve.dateNaissance,
      sexe: eleve.sexe, classeId: eleve.classeId, parentContact: eleve.parentContact,
      adresse: eleve.adresse,
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.nom || !formData.prenom || !formData.classeId) {
      toast({ title: 'Erreur', description: 'Veuillez remplir tous les champs obligatoires.', variant: 'destructive' });
      return;
    }
    if (editingEleve) {
      updateEleve(editingEleve.id, { ...formData });
      toast({ title: 'Élève modifié', description: `${formData.prenom} ${formData.nom} a été mis(e) à jour.` });
    } else {
      addEleve({
        ...formData, cycle: (classes.find((c) => c.id === formData.classeId)?.cycle || parametres.cyclesActifs[0]), photo: '', statut: 'actif',
      });
      toast({ title: 'Élève ajouté', description: `${formData.prenom} ${formData.nom} a été inscrit(e).` });
    }
    setDialogOpen(false);
  };

  const handleDelete = (id: string) => {
    setDeleteId(id);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (deleteId) {
      const eleve = eleves.find((e) => e.id === deleteId);
      deleteEleve(deleteId);
      toast({ title: 'Élève supprimé', description: `${eleve?.prenom} ${eleve?.nom} a été supprimé(e).` });
    }
    setDeleteDialogOpen(false);
    setDeleteId(null);
  };

  const getClassName = (classeId: string) => {
    const c = classes.find((cl) => cl.id === classeId);
    return c?.niveau || 'N/A';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Élèves</h1>
          <p className="text-muted-foreground">
            Gestion des élèves — {filteredEleves.length} élève(s) affiché(s)
          </p>
        </div>
        <Button onClick={openAddDialog} className="gap-2">
          <Plus className="h-4 w-4" />
          Inscrire un élève
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Rechercher par nom ou prénom..."
            className="pl-9"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Select value={filterClasse} onValueChange={setFilterClasse}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Toutes les classes" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Toutes les classes</SelectItem>
            {cycleClasses.map((c) => (
              <SelectItem key={c.id} value={c.id}>{c.niveau}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      {filteredEleves.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium">Aucun élève trouvé</p>
            <p className="text-sm text-muted-foreground">
              Modifiez vos critères de recherche ou inscrivez un nouvel élève.
            </p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">N°</TableHead>
                    <TableHead>Nom complet</TableHead>
                    <TableHead className="hidden md:table-cell">Sexe</TableHead>
                    <TableHead className="hidden sm:table-cell">Date de naissance</TableHead>
                    <TableHead>Classe</TableHead>
                    <TableHead className="hidden lg:table-cell">Contact parent</TableHead>
                    <TableHead>Statut</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredEleves.map((eleve, idx) => (
                    <TableRow key={eleve.id}>
                      <TableCell className="text-muted-foreground">{idx + 1}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="h-8 w-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 text-xs font-bold shrink-0">
                            {eleve.prenom[0]}{eleve.nom[0]}
                          </div>
                          <div>
                            <p className="font-medium">{eleve.nom} {eleve.prenom}</p>
                            <p className="text-xs text-muted-foreground md:hidden">{eleve.sexe === 'M' ? 'Masculin' : 'Féminin'}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        <Badge variant={eleve.sexe === 'M' ? 'default' : 'secondary'}>
                          {eleve.sexe === 'M' ? 'M' : 'F'}
                        </Badge>
                      </TableCell>
                      <TableCell className="hidden sm:table-cell text-sm">
                        {new Date(eleve.dateNaissance).toLocaleDateString('fr-FR')}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{getClassName(eleve.classeId)}</Badge>
                      </TableCell>
                      <TableCell className="hidden lg:table-cell text-sm">{eleve.parentContact}</TableCell>
                      <TableCell>
                        <Badge variant={eleve.statut === 'actif' ? 'default' : 'destructive'}>
                          {eleve.statut === 'actif' ? 'Actif' : 'Inactif'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setSelectedEleve(eleve); setDetailDialogOpen(true); }}>
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEditDialog(eleve)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => handleDelete(eleve.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingEleve ? 'Modifier l\'élève' : 'Inscrire un élève'}</DialogTitle>
            <DialogDescription>
              {editingEleve ? 'Modifiez les informations de l\'élève.' : 'Remplissez les informations du nouvel élève.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Nom *</Label>
                <Input placeholder="Nom de famille" value={formData.nom} onChange={(e) => setFormData({ ...formData, nom: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Prénom *</Label>
                <Input placeholder="Prénom" value={formData.prenom} onChange={(e) => setFormData({ ...formData, prenom: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Date de naissance</Label>
                <Input type="date" value={formData.dateNaissance} onChange={(e) => setFormData({ ...formData, dateNaissance: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Sexe</Label>
                <Select value={formData.sexe} onValueChange={(v: 'M' | 'F') => setFormData({ ...formData, sexe: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="M">Masculin</SelectItem>
                    <SelectItem value="F">Féminin</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Classe *</Label>
              <Select value={formData.classeId} onValueChange={(v) => setFormData({ ...formData, classeId: v })}>
                <SelectTrigger><SelectValue placeholder="Sélectionnez une classe" /></SelectTrigger>
                <SelectContent>
                  {cycleClasses.map((c) => (
                    <SelectItem key={c.id} value={c.id}>{c.niveau}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Contact parent</Label>
              <Input placeholder="+221 77 XXX XX XX" value={formData.parentContact} onChange={(e) => setFormData({ ...formData, parentContact: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Adresse</Label>
              <Input placeholder="Adresse de l'élève" value={formData.adresse} onChange={(e) => setFormData({ ...formData, adresse: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">
              {editingEleve ? 'Enregistrer' : 'Inscrire'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Fiche de l&apos;élève</DialogTitle>
          </DialogHeader>
          {selectedEleve && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="h-16 w-16 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 text-xl font-bold">
                  {selectedEleve.prenom[0]}{selectedEleve.nom[0]}
                </div>
                <div>
                  <h3 className="text-lg font-semibold">{selectedEleve.nom} {selectedEleve.prenom}</h3>
                  <Badge variant="outline">{getClassName(selectedEleve.classeId)}</Badge>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Sexe</p>
                  <p className="font-medium">{selectedEleve.sexe === 'M' ? 'Masculin' : 'Féminin'}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Date de naissance</p>
                  <p className="font-medium">{new Date(selectedEleve.dateNaissance).toLocaleDateString('fr-FR')}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Contact parent</p>
                  <p className="font-medium">{selectedEleve.parentContact}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Adresse</p>
                  <p className="font-medium">{selectedEleve.adresse}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Statut</p>
                  <Badge variant={selectedEleve.statut === 'actif' ? 'default' : 'destructive'}>
                    {selectedEleve.statut === 'actif' ? 'Actif' : 'Inactif'}
                  </Badge>
                </div>
                <div>
                  <p className="text-muted-foreground">Cycle</p>
                  <p className="font-medium">{selectedEleve.cycle}</p>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDetailDialogOpen(false)}>Fermer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirmer la suppression</DialogTitle>
            <DialogDescription>
              Êtes-vous sûr de vouloir supprimer cet élève ? Toutes ses données (notes, présences, bulletins) seront supprimées.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>Annuler</Button>
            <Button variant="destructive" onClick={confirmDelete}>Supprimer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
