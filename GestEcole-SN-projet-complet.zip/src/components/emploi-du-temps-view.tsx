'use client';

import { useState, useMemo } from 'react';
import { useAppStore } from '@/lib/store';
import type { Cours } from '@/lib/types';
import { JOURS_SEMAINE, MATIERES } from '@/lib/types';
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Plus, Pencil, Trash2, CalendarDays, Clock, MapPin, User,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const HEURES = ['08:00', '08:55', '09:50', '10:45', '11:40', '14:00', '14:55', '15:50', '16:45'];

const MATIERE_COLORS: Record<string, string> = {
  'Mathématiques': 'bg-blue-100 text-blue-800 border-blue-200',
  'Français': 'bg-emerald-100 text-emerald-800 border-emerald-200',
  'Anglais': 'bg-purple-100 text-purple-800 border-purple-200',
  'Sciences': 'bg-amber-100 text-amber-800 border-amber-200',
  'Histoire-Géo': 'bg-rose-100 text-rose-800 border-rose-200',
  'Physique-Chimie': 'bg-cyan-100 text-cyan-800 border-cyan-200',
  'SVT': 'bg-lime-100 text-lime-800 border-lime-200',
  'Philosophie': 'bg-indigo-100 text-indigo-800 border-indigo-200',
  'Éveil': 'bg-orange-100 text-orange-800 border-orange-200',
  'Dessin': 'bg-pink-100 text-pink-800 border-pink-200',
  'Musique': 'bg-teal-100 text-teal-800 border-teal-200',
  'Éducation Physique': 'bg-red-100 text-red-800 border-red-200',
  'Langue': 'bg-violet-100 text-violet-800 border-violet-200',
  'EPS': 'bg-red-100 text-red-800 border-red-200',
};

export function EmploiDuTempsView() {
  const classes = useAppStore((s) => s.classes);
  const cours = useAppStore((s) => s.cours);
  const parametres = useAppStore((s) => s.parametres);
  const { addCours, updateCours, deleteCours } = useAppStore();
  const { toast } = useToast();

  const cycleClasses = classes.filter((c) => parametres.cyclesActifs.includes(c.cycle));
  const matieres = [...new Set(parametres.cyclesActifs.flatMap((c) => MATIERES[c]))];

  const [selectedClasse, setSelectedClasse] = useState<string>(cycleClasses[0]?.id || '');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingCours, setEditingCours] = useState<Cours | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    matiere: '', classeId: '', jour: 'Lundi', heureDebut: '08:00', heureFin: '08:55',
    enseignant: '', salle: '',
  });

  const filteredCours = useMemo(() => {
    if (!selectedClasse) return [];
    return cours
      .filter((c) => c.classeId === selectedClasse)
      .sort((a, b) => {
        const jourComp = JOURS_SEMAINE.indexOf(a.jour) - JOURS_SEMAINE.indexOf(b.jour);
        if (jourComp !== 0) return jourComp;
        return a.heureDebut.localeCompare(b.heureDebut);
      });
  }, [cours, selectedClasse]);

  const getCoursAt = (jour: string, heure: string) => {
    return filteredCours.find((c) => c.jour === jour && c.heureDebut === heure);
  };

  const openAddDialog = () => {
    setEditingCours(null);
    setFormData({
      matiere: matieres[0] || '', classeId: selectedClasse, jour: 'Lundi',
      heureDebut: '08:00', heureFin: '08:55', enseignant: '', salle: '',
    });
    setDialogOpen(true);
  };

  const openEditDialog = (c: Cours) => {
    setEditingCours(c);
    setFormData({
      matiere: c.matiere, classeId: c.classeId, jour: c.jour,
      heureDebut: c.heureDebut, heureFin: c.heureFin,
      enseignant: c.enseignant, salle: c.salle,
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.matiere || !formData.jour || !formData.heureDebut) {
      toast({ title: 'Erreur', description: 'Veuillez remplir tous les champs obligatoires.', variant: 'destructive' });
      return;
    }
    if (editingCours) {
      updateCours(editingCours.id, { ...formData });
      toast({ title: 'Cours modifié' });
    } else {
      addCours({ ...formData });
      toast({ title: 'Cours ajouté' });
    }
    setDialogOpen(false);
  };

  const handleDelete = (id: string) => {
    setDeleteId(id);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (deleteId) {
      deleteCours(deleteId);
      toast({ title: 'Cours supprimé' });
    }
    setDeleteDialogOpen(false);
    setDeleteId(null);
  };

  const getMatiereColor = (matiere: string) => {
    return MATIERE_COLORS[matiere] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Emploi du Temps</h1>
          <p className="text-muted-foreground">Planification hebdomadaire des cours</p>
        </div>
        <Button onClick={openAddDialog} className="gap-2">
          <Plus className="h-4 w-4" />
          Ajouter un cours
        </Button>
      </div>

      {/* Filter */}
      <Select value={selectedClasse} onValueChange={setSelectedClasse}>
        <SelectTrigger className="w-full sm:w-64">
          <SelectValue placeholder="Sélectionnez une classe" />
        </SelectTrigger>
        <SelectContent>
          {cycleClasses.map((c) => (
            <SelectItem key={c.id} value={c.id}>{c.niveau}</SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Schedule Grid */}
      {!selectedClasse ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <CalendarDays className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium">Sélectionnez une classe</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse min-w-[700px]">
                <thead>
                  <tr className="border-b">
                    <th className="p-3 text-left text-xs font-medium text-muted-foreground bg-muted/50 min-w-[80px]">Heure</th>
                    {JOURS_SEMAINE.map((jour) => (
                      <th key={jour} className="p-3 text-center text-xs font-medium text-muted-foreground bg-muted/50">
                        {jour}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {HEURES.map((heure, idx) => {
                    const heureFin = HEURES[idx + 1] || '';
                    return (
                      <tr key={heure} className="border-b last:border-b-0">
                        <td className="p-2 text-xs text-muted-foreground font-medium bg-muted/30 align-top">
                          <div>{heure}</div>
                          {heureFin && <div className="text-[10px]">↓ {heureFin}</div>}
                        </td>
                        {JOURS_SEMAINE.map((jour) => {
                          const c = getCoursAt(jour, heure);
                          return (
                            <td key={`${jour}-${heure}`} className="p-1 align-top">
                              {c ? (
                                <div
                                  className={`p-2 rounded-lg border cursor-pointer hover:shadow-md transition-shadow ${getMatiereColor(c.matiere)}`}
                                  onClick={() => openEditDialog(c)}
                                >
                                  <p className="text-xs font-semibold">{c.matiere}</p>
                                  <p className="text-[10px] opacity-80 flex items-center gap-0.5 mt-1">
                                    <User className="h-2.5 w-2.5" />
                                    {c.enseignant}
                                  </p>
                                  <p className="text-[10px] opacity-80 flex items-center gap-0.5 mt-0.5">
                                    <MapPin className="h-2.5 w-2.5" />
                                    {c.salle}
                                  </p>
                                  <p className="text-[10px] opacity-80 flex items-center gap-0.5 mt-0.5">
                                    <Clock className="h-2.5 w-2.5" />
                                    {c.heureDebut} - {c.heureFin}
                                  </p>
                                  <div className="flex gap-1 mt-1.5">
                                    <button
                                      className="text-[10px] px-1.5 py-0.5 bg-white/50 rounded hover:bg-white/80"
                                      onClick={(e) => { e.stopPropagation(); openEditDialog(c); }}
                                    >
                                      <Pencil className="h-2.5 w-2.5 inline" />
                                    </button>
                                    <button
                                      className="text-[10px] px-1.5 py-0.5 bg-white/50 rounded hover:bg-white/80 text-red-600"
                                      onClick={(e) => { e.stopPropagation(); handleDelete(c.id); }}
                                    >
                                      <Trash2 className="h-2.5 w-2.5 inline" />
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <div
                                  className="p-2 rounded-lg border border-dashed border-muted-foreground/20 hover:border-emerald-300 hover:bg-emerald-50/30 transition-colors cursor-pointer min-h-[60px] flex items-center justify-center"
                                  onClick={() => {
                                    setEditingCours(null);
                                    setFormData({
                                      matiere: matieres[0] || '', classeId: selectedClasse, jour,
                                      heureDebut: heure, heureFin: heureFin || '09:00',
                                      enseignant: '', salle: '',
                                    });
                                    setDialogOpen(true);
                                  }}
                                >
                                  <span className="text-muted-foreground/40 text-lg">+</span>
                                </div>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Legend */}
      <Card>
        <CardContent className="pt-4">
          <p className="text-sm text-muted-foreground mb-2">Légende des matières :</p>
          <div className="flex flex-wrap gap-2">
            {matieres.map((m) => (
              <Badge key={m} variant="outline" className={getMatiereColor(m)}>{m}</Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingCours ? 'Modifier le cours' : 'Ajouter un cours'}</DialogTitle>
            <DialogDescription>
              {editingCours ? 'Modifiez les informations du cours.' : 'Planifiez un nouveau cours.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Matière *</Label>
              <Select value={formData.matiere} onValueChange={(v) => setFormData({ ...formData, matiere: v })}>
                <SelectTrigger><SelectValue placeholder="Sélectionnez" /></SelectTrigger>
                <SelectContent>
                  {matieres.map((m) => (
                    <SelectItem key={m} value={m}>{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Jour *</Label>
              <Select value={formData.jour} onValueChange={(v) => setFormData({ ...formData, jour: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {JOURS_SEMAINE.map((j) => (
                    <SelectItem key={j} value={j}>{j}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Heure début *</Label>
                <Select value={formData.heureDebut} onValueChange={(v) => setFormData({ ...formData, heureDebut: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {HEURES.map((h) => (
                      <SelectItem key={h} value={h}>{h}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Heure fin</Label>
                <Select value={formData.heureFin} onValueChange={(v) => setFormData({ ...formData, heureFin: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {HEURES.map((h) => (
                      <SelectItem key={h} value={h}>{h}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Enseignant</Label>
              <Input placeholder="Nom de l'enseignant" value={formData.enseignant} onChange={(e) => setFormData({ ...formData, enseignant: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Salle</Label>
              <Input placeholder="Salle de cours" value={formData.salle} onChange={(e) => setFormData({ ...formData, salle: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">
              {editingCours ? 'Enregistrer' : 'Ajouter'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Supprimer ce cours ?</DialogTitle>
            <DialogDescription>Cette action est irréversible.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>Annuler</Button>
            <Button variant="destructive" onClick={confirmDelete}>Supprimer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
