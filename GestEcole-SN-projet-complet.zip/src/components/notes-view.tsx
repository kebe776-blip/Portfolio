'use client';

import { useState, useMemo } from 'react';
import { useAppStore } from '@/lib/store';
import type { Note, Trimestre } from '@/lib/types';
import { MATIERES } from '@/lib/types';
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Plus, Pencil, Trash2, BookOpen, Calculator,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function NotesView() {
  const eleves = useAppStore((s) => s.eleves);
  const classes = useAppStore((s) => s.classes);
  const notes = useAppStore((s) => s.notes);
  const parametres = useAppStore((s) => s.parametres);
  const { addNote, updateNote, deleteNote } = useAppStore();
  const { toast } = useToast();

  const cycleClasses = classes.filter((c) => c.cycle === parametres.cycleActuel);
  const cycleEleves = eleves.filter((e) => e.cycle === parametres.cycleActuel && e.statut === 'actif');
  const matieres = MATIERES[parametres.cycleActuel];

  const [selectedClasse, setSelectedClasse] = useState<string>(cycleClasses[0]?.id || '');
  const [selectedTrimestre, setSelectedTrimestre] = useState<Trimestre>(1);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    eleveId: '', matiere: '', note: 0, coefficient: 2,
    trimestre: 1 as Trimestre, date: '', commentaire: '',
  });

  const filteredEleves = useMemo(() => {
    if (!selectedClasse) return [];
    return cycleEleves.filter((e) => e.classeId === selectedClasse);
  }, [cycleEleves, selectedClasse]);

  const filteredNotes = useMemo(() => {
    if (!selectedClasse) return [];
    const classeEleveIds = filteredEleves.map((e) => e.id);
    return notes.filter((n) => classeEleveIds.includes(n.eleveId) && n.trimestre === selectedTrimestre);
  }, [notes, filteredEleves, selectedTrimestre]);

  // Build a structured view: matiere -> rows per student
  const notesByMatiere = useMemo(() => {
    const result: Record<string, Record<string, Note>> = {};
    for (const matiere of matieres) {
      result[matiere] = {};
      for (const eleve of filteredEleves) {
        const note = filteredNotes.find(
          (n) => n.eleveId === eleve.id && n.matiere === matiere
        );
        if (note) result[matiere][eleve.id] = note;
      }
    }
    return result;
  }, [filteredNotes, filteredEleves, matieres]);

  const getEleveMoyenne = (eleveId: string) => {
    const eleveNotes = filteredNotes.filter((n) => n.eleveId === eleveId);
    if (eleveNotes.length === 0) return '-';
    let totalPondere = 0;
    let totalCoef = 0;
    eleveNotes.forEach((n) => {
      totalPondere += n.note * n.coefficient;
      totalCoef += n.coefficient;
    });
    return totalCoef > 0 ? (totalPondere / totalCoef).toFixed(2) : '-';
  };

  const getMatiereMoyenne = (matiere: string) => {
    const mNotes = Object.values(notesByMatiere[matiere]).filter(Boolean);
    if (mNotes.length === 0) return '-';
    const sum = mNotes.reduce((acc, n) => acc + n.note, 0);
    return (sum / mNotes.length).toFixed(2);
  };

  const getNoteColor = (note: number) => {
    if (note >= 14) return 'text-emerald-600 font-semibold';
    if (note >= 10) return 'text-blue-600';
    if (note >= 8) return 'text-amber-600';
    return 'text-red-600 font-semibold';
  };

  const openAddDialog = () => {
    setEditingNote(null);
    setFormData({
      eleveId: filteredEleves[0]?.id || '', matiere: matieres[0] || '',
      note: 10, coefficient: 2, trimestre: selectedTrimestre,
      date: new Date().toISOString().split('T')[0], commentaire: '',
    });
    setDialogOpen(true);
  };

  const openEditDialog = (note: Note) => {
    setEditingNote(note);
    setFormData({
      eleveId: note.eleveId, matiere: note.matiere, note: note.note,
      coefficient: note.coefficient, trimestre: note.trimestre,
      date: note.date, commentaire: note.commentaire,
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.eleveId || !formData.matiere) {
      toast({ title: 'Erreur', description: 'Veuillez sélectionner un élève et une matière.', variant: 'destructive' });
      return;
    }
    if (editingNote) {
      updateNote(editingNote.id, { ...formData });
      toast({ title: 'Note modifiée', description: 'La note a été mise à jour.' });
    } else {
      addNote({ ...formData });
      toast({ title: 'Note ajoutée', description: 'La note a été enregistrée.' });
    }
    setDialogOpen(false);
  };

  const handleDelete = (id: string) => {
    setDeleteId(id);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (deleteId) {
      deleteNote(deleteId);
      toast({ title: 'Note supprimée' });
    }
    setDeleteDialogOpen(false);
    setDeleteId(null);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Notes</h1>
          <p className="text-muted-foreground">Saisie et gestion des notes</p>
        </div>
        <Button onClick={openAddDialog} className="gap-2">
          <Plus className="h-4 w-4" />
          Ajouter une note
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <Select value={selectedClasse} onValueChange={setSelectedClasse}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Sélectionnez une classe" />
          </SelectTrigger>
          <SelectContent>
            {cycleClasses.map((c) => (
              <SelectItem key={c.id} value={c.id}>{c.niveau}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={String(selectedTrimestre)} onValueChange={(v) => setSelectedTrimestre(Number(v) as Trimestre)}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="1">1er Trimestre</SelectItem>
            <SelectItem value="2">2ème Trimestre</SelectItem>
            <SelectItem value="3">3ème Trimestre</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Notes Table */}
      {!selectedClasse ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <BookOpen className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium">Sélectionnez une classe</p>
          </CardContent>
        </Card>
      ) : filteredEleves.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <BookOpen className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium">Aucun élève dans cette classe</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="sticky left-0 bg-background min-w-[140px]">Élève</TableHead>
                    {matieres.map((matiere) => (
                      <TableHead key={matiere} className="min-w-[100px] text-center">
                        <div className="flex flex-col items-center gap-0.5">
                          <span className="text-xs font-medium">{matiere}</span>
                          {getMatiereMoyenne(matiere) !== '-' && (
                            <span className="text-[10px] text-muted-foreground">Moy: {getMatiereMoyenne(matiere)}</span>
                          )}
                        </div>
                      </TableHead>
                    ))}
                    <TableHead className="text-center min-w-[80px]">Moyenne</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredEleves.map((eleve) => (
                    <TableRow key={eleve.id}>
                      <TableCell className="sticky left-0 bg-background font-medium">
                        <span className="text-sm">{eleve.nom} {eleve.prenom[0]}.</span>
                      </TableCell>
                      {matieres.map((matiere) => {
                        const note = notesByMatiere[matiere]?.[eleve.id];
                        return (
                          <TableCell key={matiere} className="text-center">
                            {note ? (
                              <div
                                className="cursor-pointer hover:bg-muted rounded px-1 py-0.5"
                                onClick={() => openEditDialog(note)}
                                title="Cliquez pour modifier"
                              >
                                <span className={getNoteColor(note.note)}>{note.note.toFixed(1)}</span>
                                <p className="text-[10px] text-muted-foreground">Coef: {note.coefficient}</p>
                              </div>
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )}
                          </TableCell>
                        );
                      })}
                      <TableCell className="text-center">
                        <Badge variant={Number(getEleveMoyenne(eleve.id)) >= 10 ? 'default' : 'destructive'} className="text-xs">
                          {getEleveMoyenne(eleve.id)}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingNote ? 'Modifier la note' : 'Ajouter une note'}</DialogTitle>
            <DialogDescription>
              {editingNote ? 'Modifiez la note de l\'élève.' : 'Saisissez une nouvelle note.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Élève *</Label>
              <Select value={formData.eleveId} onValueChange={(v) => setFormData({ ...formData, eleveId: v })}>
                <SelectTrigger><SelectValue placeholder="Sélectionnez un élève" /></SelectTrigger>
                <SelectContent>
                  {filteredEleves.map((e) => (
                    <SelectItem key={e.id} value={e.id}>{e.nom} {e.prenom}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Matière *</Label>
              <Select value={formData.matiere} onValueChange={(v) => setFormData({ ...formData, matiere: v })}>
                <SelectTrigger><SelectValue placeholder="Sélectionnez une matière" /></SelectTrigger>
                <SelectContent>
                  {matieres.map((m) => (
                    <SelectItem key={m} value={m}>{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Note (sur 20) *</Label>
                <Input
                  type="number" min="0" max="20" step="0.5"
                  value={formData.note}
                  onChange={(e) => setFormData({ ...formData, note: parseFloat(e.target.value) || 0 })}
                />
              </div>
              <div className="space-y-2">
                <Label>Coefficient</Label>
                <Input
                  type="number" min="1" max="10"
                  value={formData.coefficient}
                  onChange={(e) => setFormData({ ...formData, coefficient: parseInt(e.target.value) || 1 })}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Date</Label>
              <Input type="date" value={formData.date} onChange={(e) => setFormData({ ...formData, date: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Commentaire</Label>
              <Input placeholder="Commentaire facultatif" value={formData.commentaire} onChange={(e) => setFormData({ ...formData, commentaire: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">
              {editingNote ? 'Enregistrer' : 'Ajouter'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Supprimer cette note ?</DialogTitle>
            <DialogDescription>Cette action est irréversible.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>Annuler</Button>
            <Button variant="destructive" onClick={confirmDelete}>Supprimer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
