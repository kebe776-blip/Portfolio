'use client';

import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import type { CycleType } from '@/lib/types';
import { CYCLE_NIVEAUX } from '@/lib/types';
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Settings, Save, RotateCcw, School, Phone, MapPin, Calendar, Palette,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const CYCLE_DESCRIPTIONS: Record<CycleType, string> = {
  'Préscolaire': 'PS, MS, GS — Éducation préscolaire (3-6 ans)',
  'Élémentaire': 'CI, CP, CE1, CE2, CM1, CM2 — Enseignement primaire (6-12 ans)',
  'Moyen': '6ème, 5ème, 4ème, 3ème — Collège (12-16 ans)',
  'Secondaire': '2nde, 1ère, Tle — Lycée (16-19 ans)',
};

export function ParametresView() {
  const parametres = useAppStore((s) => s.parametres);
  const eleves = useAppStore((s) => s.eleves);
  const classes = useAppStore((s) => s.classes);
  const notes = useAppStore((s) => s.notes);
  const { updateParametres, toggleCycle, resetData } = useAppStore();
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    nomEcole: parametres.nomEcole,
    adresse: parametres.adresse,
    telephone: parametres.telephone,
    anneeScolaire: parametres.anneeScolaire,
  });

  const [resetDialogOpen, setResetDialogOpen] = useState(false);

  const handleSave = () => {
    updateParametres(formData);
    toast({ title: 'Paramètres enregistrés', description: 'Les informations de l\'école ont été mises à jour.' });
  };

  const handleReset = () => {
    resetData();
    setResetDialogOpen(false);
    toast({ title: 'Données réinitialisées', description: 'Toutes les données ont été restaurées aux valeurs par défaut.' });
  };

  // Statistics
  const totalEleves = eleves.filter((e) => e.statut === 'actif').length;
  const totalClasses = classes.length;
  const totalNotes = notes.length;
  const cycleEleves = eleves.filter((e) => parametres.cyclesActifs.includes(e.cycle) && e.statut === 'actif');
  const cycleClasses = classes.filter((c) => parametres.cyclesActifs.includes(c.cycle));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Paramètres</h1>
        <p className="text-muted-foreground">Configuration de l&apos;application et de l&apos;école</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* School Information */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <School className="h-5 w-5 text-emerald-600" />
              <CardTitle className="text-base">Informations de l&apos;école</CardTitle>
            </div>
            <CardDescription>Modifiez les informations de votre établissement</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <School className="h-3 w-3" />
                Nom de l&apos;école
              </Label>
              <Input
                value={formData.nomEcole}
                onChange={(e) => setFormData({ ...formData, nomEcole: e.target.value })}
                placeholder="Nom de l'établissement"
              />
            </div>
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <MapPin className="h-3 w-3" />
                Adresse
              </Label>
              <Input
                value={formData.adresse}
                onChange={(e) => setFormData({ ...formData, adresse: e.target.value })}
                placeholder="Adresse de l'école"
              />
            </div>
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Phone className="h-3 w-3" />
                Téléphone
              </Label>
              <Input
                value={formData.telephone}
                onChange={(e) => setFormData({ ...formData, telephone: e.target.value })}
                placeholder="+221 33 XXX XX XX"
              />
            </div>
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Calendar className="h-3 w-3" />
                Année scolaire
              </Label>
              <Input
                value={formData.anneeScolaire}
                onChange={(e) => setFormData({ ...formData, anneeScolaire: e.target.value })}
                placeholder="2024-2025"
              />
            </div>
            <Button onClick={handleSave} className="w-full gap-2 bg-emerald-600 hover:bg-emerald-700">
              <Save className="h-4 w-4" />
              Enregistrer les modifications
            </Button>
          </CardContent>
        </Card>

        {/* Cycle Selection */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Palette className="h-5 w-5 text-emerald-600" />
              <CardTitle className="text-base">Cycle scolaire</CardTitle>
            </div>
            <CardDescription>
              Activez ou désactivez les cycles. Tous les modules s&apos;adapteront automatiquement.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Active Cycles Summary */}
            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4">
              <p className="text-sm text-muted-foreground">Cycles actifs</p>
              <p className="text-lg font-bold text-emerald-700">{parametres.cyclesActifs.join(', ')}</p>
              <div className="flex gap-2 mt-3">
                <Badge variant="secondary">{cycleEleves.length} élèves</Badge>
                <Badge variant="secondary">{cycleClasses.length} classes</Badge>
              </div>
            </div>

            <Separator />

            {/* Cycle Toggles */}
            <div className="space-y-2">
              <Label>Gérer les cycles actifs</Label>
              <div className="grid grid-cols-1 gap-2">
                {(Object.keys(CYCLE_NIVEAUX) as CycleType[]).map((cycle) => {
                  const isActive = parametres.cyclesActifs.includes(cycle);
                  return (
                    <button
                      key={cycle}
                      className={`w-full text-left p-3 rounded-lg border transition-colors ${
                        isActive
                          ? 'border-emerald-300 bg-emerald-50'
                          : 'border-muted hover:border-emerald-200 hover:bg-emerald-50/50'
                      }`}
                      onClick={() => {
                        toggleCycle(cycle);
                        toast({
                          title: isActive ? 'Cycle désactivé' : 'Cycle activé',
                          description: isActive
                            ? `Le cycle "${cycle}" a été désactivé.`
                            : `Le cycle "${cycle}" est maintenant actif.`,
                        });
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-sm">{cycle}</p>
                          <p className="text-xs text-muted-foreground">{CYCLE_DESCRIPTIONS[cycle]}</p>
                        </div>
                        <div className="flex gap-1 flex-wrap justify-end">
                          {CYCLE_NIVEAUX[cycle].map((n) => (
                            <Badge key={n} variant="outline" className="text-[10px]">{n}</Badge>
                          ))}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Data Management */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Settings className="h-5 w-5 text-emerald-600" />
            <CardTitle className="text-base">Gestion des données</CardTitle>
          </div>
          <CardDescription>Gérez les données de l&apos;application</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-muted/50 rounded-lg p-4">
              <p className="text-sm text-muted-foreground">Total Élèves</p>
              <p className="text-2xl font-bold">{totalEleves}</p>
            </div>
            <div className="bg-muted/50 rounded-lg p-4">
              <p className="text-sm text-muted-foreground">Total Classes</p>
              <p className="text-2xl font-bold">{totalClasses}</p>
            </div>
            <div className="bg-muted/50 rounded-lg p-4">
              <p className="text-sm text-muted-foreground">Total Notes</p>
              <p className="text-2xl font-bold">{totalNotes}</p>
            </div>
            <div className="bg-muted/50 rounded-lg p-4">
              <p className="text-sm text-muted-foreground">Année scolaire</p>
              <p className="text-2xl font-bold">{parametres.anneeScolaire}</p>
            </div>
          </div>

          <Separator className="my-4" />

          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              variant="outline"
              className="gap-2 text-destructive hover:text-destructive"
              onClick={() => setResetDialogOpen(true)}
            >
              <RotateCcw className="h-4 w-4" />
              Réinitialiser les données
            </Button>
            <p className="text-xs text-muted-foreground flex items-center">
              ⚠️ La réinitialisation supprimera toutes les modifications et restaurera les données d&apos;exemple.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Reset Dialog */}
      <Dialog open={resetDialogOpen} onOpenChange={setResetDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Réinitialiser les données ?</DialogTitle>
            <DialogDescription>
              Cette action supprimera toutes vos modifications et restaurera les données d&apos;exemple. Cette action est irréversible.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setResetDialogOpen(false)}>Annuler</Button>
            <Button variant="destructive" onClick={handleReset}>Réinitialiser</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
