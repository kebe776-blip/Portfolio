'use client';

import { useState, useMemo } from 'react';
import { useAppStore } from '@/lib/store';
import type { Presence, StatutPresence } from '@/lib/types';
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import {
  ClipboardCheck, CheckCircle, XCircle, Clock, Save,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const statutConfig: Record<StatutPresence, { label: string; color: string; icon: React.ComponentType<{ className?: string }> }> = {
  present: { label: 'Présent', color: 'bg-emerald-100 text-emerald-700', icon: CheckCircle },
  absent: { label: 'Absent', color: 'bg-red-100 text-red-700', icon: XCircle },
  retard: { label: 'Retard', color: 'bg-amber-100 text-amber-700', icon: Clock },
};

export function PresencesView() {
  const eleves = useAppStore((s) => s.eleves);
  const classes = useAppStore((s) => s.classes);
  const presences = useAppStore((s) => s.presences);
  const parametres = useAppStore((s) => s.parametres);
  const { addPresence, updatePresence } = useAppStore();
  const { toast } = useToast();

  const cycleClasses = classes.filter((c) => parametres.cyclesActifs.includes(c.cycle));

  const [selectedClasse, setSelectedClasse] = useState<string>(cycleClasses[0]?.id || '');
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [presenceStates, setPresenceStates] = useState<Record<string, StatutPresence>>({});
  const [motifDialogOpen, setMotifDialogOpen] = useState(false);
  const [currentEleveId, setcurrentEleveId] = useState<string>('');
  const [motif, setMotif] = useState('');

  const filteredEleves = useMemo(() => {
    if (!selectedClasse) return [];
    return eleves.filter((e) => e.classeId === selectedClasse && e.statut === 'actif');
  }, [eleves, selectedClasse]);

  // Load existing presences for selected date
  const existingPresences = useMemo(() => {
    return presences.filter((p) => p.date === selectedDate);
  }, [presences, selectedDate]);

  // Initialize presence states
  useMemo(() => {
    const states: Record<string, StatutPresence> = {};
    filteredEleves.forEach((e) => {
      const existing = existingPresences.find((p) => p.eleveId === e.id);
      states[e.id] = existing?.statut || 'present';
    });
    setPresenceStates(states);
  }, [filteredEleves, selectedDate]);

  const handleStatutChange = (eleveId: string, statut: StatutPresence) => {
    if (statut !== 'present') {
      setcurrentEleveId(eleveId);
      setMotif('');
      setMotifDialogOpen(true);
    }
    setPresenceStates((prev) => ({ ...prev, [eleveId]: statut }));
  };

  const handleMotifSave = () => {
    setMotifDialogOpen(false);
  };

  const handleSaveAll = () => {
    const existingIds = new Set(existingPresences.map((p) => p.eleveId));
    let count = 0;
    filteredEleves.forEach((e) => {
      const statut = presenceStates[e.id];
      if (existingIds.has(e.id)) {
        const existing = existingPresences.find((p) => p.eleveId === e.id)!;
        updatePresence(existing.id, { statut, motif: statut !== 'present' ? motif : '' });
      } else {
        addPresence({
          eleveId: e.id,
          date: selectedDate,
          statut,
          motif: statut !== 'present' ? motif : '',
        });
      }
      count++;
    });
    toast({ title: 'Présences enregistrées', description: `Appel du ${new Date(selectedDate).toLocaleDateString('fr-FR')} sauvegardé pour ${count} élèves.` });
  };

  // Stats
  const stats = useMemo(() => {
    const values = Object.values(presenceStates);
    return {
      present: values.filter((v) => v === 'present').length,
      absent: values.filter((v) => v === 'absent').length,
      retard: values.filter((v) => v === 'retard').length,
    };
  }, [presenceStates]);

  // History data for last 7 days
  const historyData = useMemo(() => {
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const dayPresences = presences.filter((p) => p.date === dateStr && filteredEleves.some((e) => e.id === p.eleveId));
      const total = dayPresences.length;
      const present = dayPresences.filter((p) => p.statut === 'present').length;
      days.push({
        date: dateStr,
        label: d.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric' }),
        total,
        present,
        taux: total > 0 ? Math.round((present / total) * 100) : 0,
      });
    }
    return days;
  }, [presences, filteredEleves]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Présences</h1>
          <p className="text-muted-foreground">Suivi de la présence et de l&apos;absence des élèves</p>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="space-y-2 flex-1">
              <Label>Classe</Label>
              <Select value={selectedClasse} onValueChange={setSelectedClasse}>
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionnez une classe" />
                </SelectTrigger>
                <SelectContent>
                  {cycleClasses.map((c) => (
                    <SelectItem key={c.id} value={c.id}>{c.niveau}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 w-full sm:w-48">
              <Label>Date</Label>
              <Input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} />
            </div>
            <div className="flex items-end">
              <Button onClick={handleSaveAll} className="gap-2 bg-emerald-600 hover:bg-emerald-700">
                <Save className="h-4 w-4" />
                Enregistrer l&apos;appel
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-emerald-50 border-emerald-200">
          <CardContent className="pt-4 text-center">
            <CheckCircle className="h-5 w-5 text-emerald-600 mx-auto mb-1" />
            <p className="text-2xl font-bold text-emerald-700">{stats.present}</p>
            <p className="text-xs text-muted-foreground">Présents</p>
          </CardContent>
        </Card>
        <Card className="bg-red-50 border-red-200">
          <CardContent className="pt-4 text-center">
            <XCircle className="h-5 w-5 text-red-600 mx-auto mb-1" />
            <p className="text-2xl font-bold text-red-700">{stats.absent}</p>
            <p className="text-xs text-muted-foreground">Absents</p>
          </CardContent>
        </Card>
        <Card className="bg-amber-50 border-amber-200">
          <CardContent className="pt-4 text-center">
            <Clock className="h-5 w-5 text-amber-600 mx-auto mb-1" />
            <p className="text-2xl font-bold text-amber-700">{stats.retard}</p>
            <p className="text-xs text-muted-foreground">Retards</p>
          </CardContent>
        </Card>
      </div>

      {/* Presence Table */}
      {!selectedClasse ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <ClipboardCheck className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium">Sélectionnez une classe</p>
          </CardContent>
        </Card>
      ) : filteredEleves.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <ClipboardCheck className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium">Aucun élève dans cette classe</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">N°</TableHead>
                    <TableHead>Nom complet</TableHead>
                    <TableHead className="text-center">Statut</TableHead>
                    <TableHead className="hidden sm:table-cell text-center">Motif</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredEleves.map((eleve, idx) => {
                    const statut = presenceStates[eleve.id] || 'present';
                    const config = statutConfig[statut];
                    const StatutIcon = config.icon;
                    return (
                      <TableRow key={eleve.id}>
                        <TableCell className="text-muted-foreground">{idx + 1}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="h-8 w-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 text-xs font-bold shrink-0">
                              {eleve.prenom[0]}{eleve.nom[0]}
                            </div>
                            <span className="font-medium">{eleve.nom} {eleve.prenom}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                                statut === 'present' ? 'bg-emerald-100 text-emerald-700 ring-2 ring-emerald-300' : 'bg-muted text-muted-foreground hover:bg-emerald-50 hover:text-emerald-700'
                              }`}
                              onClick={() => handleStatutChange(eleve.id, 'present')}
                            >
                              <CheckCircle className="h-3 w-3" />
                              P
                            </button>
                            <button
                              className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                                statut === 'absent' ? 'bg-red-100 text-red-700 ring-2 ring-red-300' : 'bg-muted text-muted-foreground hover:bg-red-50 hover:text-red-700'
                              }`}
                              onClick={() => handleStatutChange(eleve.id, 'absent')}
                            >
                              <XCircle className="h-3 w-3" />
                              A
                            </button>
                            <button
                              className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                                statut === 'retard' ? 'bg-amber-100 text-amber-700 ring-2 ring-amber-300' : 'bg-muted text-muted-foreground hover:bg-amber-50 hover:text-amber-700'
                              }`}
                              onClick={() => handleStatutChange(eleve.id, 'retard')}
                            >
                              <Clock className="h-3 w-3" />
                              R
                            </button>
                          </div>
                        </TableCell>
                        <TableCell className="hidden sm:table-cell text-center">
                          {statut !== 'present' ? (
                            <Input
                              className="max-w-[200px] mx-auto"
                              placeholder="Motif..."
                              defaultValue={presences.find((p) => p.eleveId === eleve.id && p.date === selectedDate)?.motif || ''}
                              onChange={(e) => {
                                const existing = presences.find((p) => p.eleveId === eleve.id && p.date === selectedDate);
                                if (existing) {
                                  updatePresence(existing.id, { motif: e.target.value });
                                }
                              }}
                            />
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Weekly History */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Historique de la semaine</CardTitle>
          <CardDescription>Taux de présence sur les 7 derniers jours</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-end gap-2 h-32">
            {historyData.map((day) => (
              <div key={day.date} className="flex-1 flex flex-col items-center gap-1">
                <span className="text-xs font-medium text-muted-foreground">{day.taux}%</span>
                <div className="w-full bg-muted rounded-t-sm overflow-hidden flex flex-col-reverse" style={{ height: '80px' }}>
                  <div
                    className={`w-full rounded-t-sm transition-all ${day.taux >= 80 ? 'bg-emerald-500' : day.taux >= 50 ? 'bg-amber-500' : 'bg-red-500'}`}
                    style={{ height: `${day.taux}%` }}
                  />
                </div>
                <span className="text-[10px] text-muted-foreground">{day.label}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Motif Dialog */}
      <Dialog open={motifDialogOpen} onOpenChange={setMotifDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Raison de l&apos;absence/retard</DialogTitle>
            <DialogDescription>Indiquez le motif (facultatif).</DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label>Motif</Label>
            <Input
              placeholder="Ex: Maladie, transport, etc."
              value={motif}
              onChange={(e) => setMotif(e.target.value)}
            />
          </div>
          <DialogFooter>
            <Button onClick={handleMotifSave} className="bg-emerald-600 hover:bg-emerald-700">OK</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
