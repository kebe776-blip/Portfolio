import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import {
  Eleve, Classe, Note, Presence, Bulletin, Cours, Parametres,
  Enseignant, AffectationEnseignant, Personnel, Periode,
  CycleType, CYCLE_NIVEAUX, CYCLE_PERIODES, MATIERES, JOURS_SEMAINE
} from './types';

// Generate unique IDs
const uid = () => Math.random().toString(36).substring(2, 11);

// Sample Senegalese names
const noms = ['Ndiaye', 'Diop', 'Fall', 'Sow', 'Ba', 'Diallo', 'Sy', 'Mbaye', 'Thiam', 'Gueye', 'Diouf', 'Kane', 'Cisse', 'Sarr', 'Seck'];
const prenomsM = ['Moussa', 'Ibrahima', 'Abdoulaye', 'Mamadou', 'Ousmane', 'Cheikh', 'Modou', 'Pape', 'Malick', 'Amadou', 'Boubacar', 'Seydou', 'Lamine', 'Aliou', 'Demba'];
const prenomsF = ['Fatou', 'Aminata', 'Mariama', 'Awa', 'Khady', 'Coumba', 'Ndèye', 'Aïssatou', 'Dieynaba', 'Sokhna', 'Maimouna', 'Adama', 'Bineta', 'Oumou', 'Rama'];

const enseignantNames = [
  { nom: 'Ndiaye', prenom: 'Moussa', sexe: 'M' as const, specialite: 'Mathématiques' },
  { nom: 'Diop', prenom: 'Fatou', sexe: 'F' as const, specialite: 'Français' },
  { nom: 'Fall', prenom: 'Cheikh', sexe: 'M' as const, specialite: 'Sciences' },
  { nom: 'Sow', prenom: 'Aminata', sexe: 'F' as const, specialite: 'Anglais' },
  { nom: 'Ba', prenom: 'Ibrahima', sexe: 'M' as const, specialite: 'Histoire-Géo' },
  { nom: 'Diallo', prenom: 'Mariama', sexe: 'F' as const, specialite: 'Éveil' },
  { nom: 'Sy', prenom: 'Ousmane', sexe: 'M' as const, specialite: 'Éducation Physique' },
  { nom: 'Thiam', prenom: 'Coumba', sexe: 'F' as const, specialite: 'Dessin' },
];
const enseignantsOld = ['M. Moussa Ndiaye', 'Mme Fatou Diop', 'M. Cheikh Fall', 'Mme Aminata Sow', 'M. Ibrahima Ba', 'Mme Mariama Diallo', 'M. Ousmane Sy', 'Mme Coumba Thiam'];
const salles = ['Salle A1', 'Salle A2', 'Salle B1', 'Salle B2', 'Salle C1', 'Salle C2'];

// Helper to create sample students
function createSampleEleves(classes: Classe[]): Eleve[] {
  const eleves: Eleve[] = [];
  let count = 0;
  for (const classe of classes) {
    const nbEleves = 3 + Math.floor(Math.random() * 3); // 3-5 students per class
    for (let i = 0; i < nbEleves && count < 25; i++) {
      const sexe = Math.random() > 0.5 ? 'M' as const : 'F' as const;
      const nom = noms[Math.floor(Math.random() * noms.length)];
      const prenom = sexe === 'M'
        ? prenomsM[Math.floor(Math.random() * prenomsM.length)]
        : prenomsF[Math.floor(Math.random() * prenomsF.length)];
      const year = 2012 + Math.floor(Math.random() * 6);
      const month = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
      const day = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
      eleves.push({
        id: uid(),
        nom,
        prenom,
        dateNaissance: `${year}-${month}-${day}`,
        sexe,
        classeId: classe.id,
        cycle: classe.cycle,
        parentContact: `+221 7${Math.floor(Math.random() * 10)}${Math.floor(Math.random() * 10)} ${Math.floor(100000 + Math.random() * 900000)}`,
        adresse: ['Médina', 'Plateau', 'Fann', ' Parcelles Assainies', 'Ouakam', 'Almadies', 'Point E', 'Mermoz', 'Sacre-Cœur', 'Grand Yoff'][Math.floor(Math.random() * 10)],
        photo: '',
        statut: 'actif',
      });
      count++;
    }
  }
  return eleves;
}

// Helper to create sample notes
function createSampleNotes(eleves: Eleve[]): Note[] {
  const notes: Note[] = [];
  const coefficients: Record<string, number> = {
    'Mathématiques': 4,
    'Français': 4,
    'Anglais': 2,
    'Sciences': 2,
    'Histoire-Géo': 2,
  };

  for (const eleve of eleves) {
    const matieres = MATIERES[eleve.cycle] || MATIERES['Élémentaire'];
    const periodes = CYCLE_PERIODES[eleve.cycle] || ['T1', 'T2', 'T3'];
    for (const matiere of matieres) {
      for (const periode of periodes) {
        const periodeNum = parseInt(periode.replace(/[^0-9]/g, ''));
        notes.push({
          id: uid(),
          eleveId: eleve.id,
          matiere,
          note: Math.round((5 + Math.random() * 15) * 10) / 10,
          coefficient: coefficients[matiere] || 2,
          periode,
          date: `2024-${String(periodeNum * 3 - 1).padStart(2, '0')}-${String(Math.floor(Math.random() * 28) + 1).padStart(2, '0')}`,
          commentaire: '',
        });
      }
    }
  }
  return notes;
}

// Helper to create sample presences
function createSamplePresences(eleves: Eleve[]): Presence[] {
  const presences: Presence[] = [];
  const motifs = ['Maladie', 'Raison familiale', 'Transport', 'Non motivé', 'Rendez-vous médical', ''];

  for (const eleve of eleves.slice(0, 15)) {
    for (let day = 1; day <= 20; day++) {
      const rand = Math.random();
      const statut = rand > 0.9 ? 'absent' as const : rand > 0.8 ? 'retard' as const : 'present' as const;
      presences.push({
        id: uid(),
        eleveId: eleve.id,
        date: `2024-10-${String(day).padStart(2, '0')}`,
        statut,
        motif: statut !== 'present' ? motifs[Math.floor(Math.random() * motifs.length)] : '',
      });
    }
  }
  return presences;
}

// Helper to create sample bulletins
function createSampleBulletins(eleves: Eleve[], notes: Note[]): Bulletin[] {
  const bulletins: Bulletin[] = [];
  const appreciations = [
    'Bon travail, continue ainsi !',
    'Des progrès constants, félicitations.',
    'Peut mieux faire, reste concentré(e).',
    'Très bon trimestre/semestre, continue dans cette voie.',
    'Des efforts à fournir dans certaines matières.',
  ];

  for (const eleve of eleves) {
    const periodes = CYCLE_PERIODES[eleve.cycle] || ['T1', 'T2', 'T3'];
    for (const periode of periodes) {
      const eleveNotes = notes.filter(n => n.eleveId === eleve.id && n.periode === periode);
      let totalCoef = 0;
      let totalPondere = 0;
      for (const n of eleveNotes) {
        totalCoef += n.coefficient;
        totalPondere += n.note * n.coefficient;
      }
      const moyenne = totalCoef > 0 ? Math.round((totalPondere / totalCoef) * 100) / 100 : 0;
      const mention = moyenne >= 16 ? 'Excellent' : moyenne >= 14 ? 'Très Bien' : moyenne >= 12 ? 'Bien' : moyenne >= 10 ? 'Assez Bien' : moyenne >= 8 ? 'Passable' : 'Insuffisant';

      bulletins.push({
        id: uid(),
        eleveId: eleve.id,
        periode,
        anneeScolaire: '2024-2025',
        appreciation: appreciations[Math.floor(Math.random() * appreciations.length)],
        mention,
        moyenne,
        rang: Math.floor(Math.random() * 15) + 1,
      });
    }
  }
  return bulletins;
}

// Helper to create sample cours (schedule)
function createSampleCours(classes: Classe[]): Cours[] {
  const cours: Cours[] = [];
  const heures = ['08:00', '09:00', '10:00', '11:00', '14:00', '15:00', '16:00'];

  for (const classe of classes) {
    const matieres = MATIERES[classe.cycle] || MATIERES['Élémentaire'];
    for (const jour of JOURS_SEMAINE) {
      const nbCours = 3 + Math.floor(Math.random() * 3);
      const shuffledMatieres = [...matieres].sort(() => Math.random() - 0.5);
      for (let i = 0; i < nbCours && i < shuffledMatieres.length; i++) {
        const startIdx = Math.floor(Math.random() * (heures.length - 1));
        cours.push({
          id: uid(),
          matiere: shuffledMatieres[i],
          classeId: classe.id,
          jour,
          heureDebut: heures[startIdx],
          heureFin: heures[startIdx + 1],
          enseignant: enseignantsOld[Math.floor(Math.random() * enseignantsOld.length)],
          salle: salles[Math.floor(Math.random() * salles.length)],
        });
      }
    }
  }
  return cours;
}

// Create sample classes for Élémentaire
function createSampleClasses(): Classe[] {
  const niveaux = CYCLE_NIVEAUX['Élémentaire'];
  return niveaux.map((niveau) => ({
    id: uid(),
    nom: `Classe de ${niveau}`,
    niveau,
    cycle: 'Élémentaire' as CycleType,
    capacite: 40,
    effectif: 0,
    anneeScolaire: '2024-2025',
  }));
}

const sampleClasses = createSampleClasses();
const sampleEleves = createSampleEleves(sampleClasses);
const sampleNotes = createSampleNotes(sampleEleves);
const samplePresences = createSamplePresences(sampleEleves);
const sampleBulletins = createSampleBulletins(sampleEleves, sampleNotes);
const sampleCours = createSampleCours(sampleClasses);

// Create sample enseignants
const sampleEnseignants: Enseignant[] = enseignantNames.map(e => ({
  id: uid(),
  nom: e.nom,
  prenom: e.prenom,
  sexe: e.sexe,
  telephone: `+221 7${Math.floor(Math.random() * 10)}${Math.floor(Math.random() * 10)} ${Math.floor(100000 + Math.random() * 900000)}`,
  email: `${e.prenom.toLowerCase()}.${e.nom.toLowerCase()}@ecole.sn`,
  specialite: e.specialite,
  statut: 'actif',
}));

// Update class effectifs
sampleClasses.forEach(classe => {
  classe.effectif = sampleEleves.filter(e => e.classeId === classe.id).length;
});

interface AppState {
  // Data
  eleves: Eleve[];
  classes: Classe[];
  notes: Note[];
  presences: Presence[];
  bulletins: Bulletin[];
  cours: Cours[];
  enseignants: Enseignant[];
  affectations: AffectationEnseignant[];
  personnels: Personnel[];
  parametres: Parametres;

  // Eleve CRUD
  addEleve: (eleve: Omit<Eleve, 'id'>) => void;
  updateEleve: (id: string, data: Partial<Eleve>) => void;
  deleteEleve: (id: string) => void;

  // Classe CRUD
  addClasse: (classe: Omit<Classe, 'id'>) => void;
  updateClasse: (id: string, data: Partial<Classe>) => void;
  deleteClasse: (id: string) => void;

  // Note CRUD
  addNote: (note: Omit<Note, 'id'>) => void;
  updateNote: (id: string, data: Partial<Note>) => void;
  deleteNote: (id: string) => void;

  // Presence CRUD
  addPresence: (presence: Omit<Presence, 'id'>) => void;
  updatePresence: (id: string, data: Partial<Presence>) => void;
  deletePresence: (id: string) => void;

  // Bulletin CRUD
  addBulletin: (bulletin: Omit<Bulletin, 'id'>) => void;
  updateBulletin: (id: string, data: Partial<Bulletin>) => void;
  deleteBulletin: (id: string) => void;

  // Cours CRUD
  addCours: (cours: Omit<Cours, 'id'>) => void;
  updateCours: (id: string, data: Partial<Cours>) => void;
  deleteCours: (id: string) => void;

  // Enseignant CRUD
  addEnseignant: (enseignant: Omit<Enseignant, 'id'>) => void;
  updateEnseignant: (id: string, data: Partial<Enseignant>) => void;
  deleteEnseignant: (id: string) => void;

  // AffectationEnseignant CRUD
  addAffectation: (affectation: Omit<AffectationEnseignant, 'id'>) => void;
  updateAffectation: (id: string, data: Partial<AffectationEnseignant>) => void;
  deleteAffectation: (id: string) => void;

  // Personnel CRUD
  addPersonnel: (personnel: Omit<Personnel, 'id'>) => void;
  updatePersonnel: (id: string, data: Partial<Personnel>) => void;
  deletePersonnel: (id: string) => void;

  // Parametres
  updateParametres: (data: Partial<Parametres>) => void;
  toggleCycle: (cycle: CycleType) => void;

  // Data Management
  generateClassesForCycle: (cycle: CycleType) => void;
  exportDataJSON: () => string;
  importDataJSON: (json: string) => boolean;

  // Helpers
  getClassesByCycle: (cycle: CycleType) => Classe[];
  getElevesByClasse: (classeId: string) => Eleve[];
  getNotesByEleve: (eleveId: string, periode?: Periode) => Note[];
  getPresencesByEleve: (eleveId: string, date?: string) => Presence[];
  getBulletin: (eleveId: string, periode: Periode) => Bulletin | undefined;
  getCoursByClasse: (classeId: string) => Cours[];
  getAffectationsByClasse: (classeId: string) => AffectationEnseignant[];
  getAffectationsByEnseignant: (enseignantId: string) => AffectationEnseignant[];
  resetData: () => void;
}

const defaultParametres: Parametres = {
  cyclesActifs: ['Élémentaire'],
  anneeScolaire: '2024-2025',
  nomEcole: 'École Primaire de Dakar',
  adresse: 'Rue 10, Médina, Dakar, Sénégal',
  telephone: '+221 33 823 45 67',
  logo: '',
};

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      eleves: sampleEleves,
      classes: sampleClasses,
      notes: sampleNotes,
      presences: samplePresences,
      bulletins: sampleBulletins,
      cours: sampleCours,
      enseignants: sampleEnseignants,
      affectations: [] as AffectationEnseignant[],
      personnels: [] as Personnel[],
      parametres: defaultParametres,

      // Eleve CRUD
      addEleve: (eleve) => set((state) => {
        const newEleve = { ...eleve, id: uid() };
        const updatedClasses = state.classes.map(c =>
          c.id === eleve.classeId ? { ...c, effectif: c.effectif + 1 } : c
        );
        return { eleves: [...state.eleves, newEleve], classes: updatedClasses };
      }),

      updateEleve: (id, data) => set((state) => {
        const oldEleve = state.eleves.find(e => e.id === id);
        let updatedClasses = state.classes;
        if (oldEleve && data.classeId && data.classeId !== oldEleve.classeId) {
          updatedClasses = state.classes.map(c => {
            if (c.id === oldEleve.classeId) return { ...c, effectif: Math.max(0, c.effectif - 1) };
            if (c.id === data.classeId) return { ...c, effectif: c.effectif + 1 };
            return c;
          });
        }
        return {
          eleves: state.eleves.map(e => e.id === id ? { ...e, ...data } : e),
          classes: updatedClasses,
        };
      }),

      deleteEleve: (id) => set((state) => {
        const eleve = state.eleves.find(e => e.id === id);
        if (!eleve) return state;
        const updatedClasses = state.classes.map(c =>
          c.id === eleve.classeId ? { ...c, effectif: Math.max(0, c.effectif - 1) } : c
        );
        return {
          eleves: state.eleves.filter(e => e.id !== id),
          notes: state.notes.filter(n => n.eleveId !== id),
          presences: state.presences.filter(p => p.eleveId !== id),
          bulletins: state.bulletins.filter(b => b.eleveId !== id),
          classes: updatedClasses,
        };
      }),

      // Classe CRUD
      addClasse: (classe) => set((state) => ({
        classes: [...state.classes, { ...classe, id: uid() }],
      })),

      updateClasse: (id, data) => set((state) => ({
        classes: state.classes.map(c => c.id === id ? { ...c, ...data } : c),
      })),

      deleteClasse: (id) => set((state) => ({
        classes: state.classes.filter(c => c.id !== id),
        eleves: state.eleves.map(e => e.classeId === id ? { ...e, statut: 'inactif' as const } : e),
        cours: state.cours.filter(c => c.classeId !== id),
      })),

      // Note CRUD
      addNote: (note) => set((state) => ({
        notes: [...state.notes, { ...note, id: uid() }],
      })),

      updateNote: (id, data) => set((state) => ({
        notes: state.notes.map(n => n.id === id ? { ...n, ...data } : n),
      })),

      deleteNote: (id) => set((state) => ({
        notes: state.notes.filter(n => n.id !== id),
      })),

      // Presence CRUD
      addPresence: (presence) => set((state) => ({
        presences: [...state.presences, { ...presence, id: uid() }],
      })),

      updatePresence: (id, data) => set((state) => ({
        presences: state.presences.map(p => p.id === id ? { ...p, ...data } : p),
      })),

      deletePresence: (id) => set((state) => ({
        presences: state.presences.filter(p => p.id !== id),
      })),

      // Bulletin CRUD
      addBulletin: (bulletin) => set((state) => ({
        bulletins: [...state.bulletins, { ...bulletin, id: uid() }],
      })),

      updateBulletin: (id, data) => set((state) => ({
        bulletins: state.bulletins.map(b => b.id === id ? { ...b, ...data } : b),
      })),

      deleteBulletin: (id) => set((state) => ({
        bulletins: state.bulletins.filter(b => b.id !== id),
      })),

      // Cours CRUD
      addCours: (cours) => set((state) => ({
        cours: [...state.cours, { ...cours, id: uid() }],
      })),

      updateCours: (id, data) => set((state) => ({
        cours: state.cours.map(c => c.id === id ? { ...c, ...data } : c),
      })),

      deleteCours: (id) => set((state) => ({
        cours: state.cours.filter(c => c.id !== id),
      })),

      // Enseignant CRUD
      addEnseignant: (enseignant) => set((state) => ({
        enseignants: [...state.enseignants, { ...enseignant, id: uid() }],
      })),

      updateEnseignant: (id, data) => set((state) => ({
        enseignants: state.enseignants.map(e => e.id === id ? { ...e, ...data } : e),
      })),

      deleteEnseignant: (id) => set((state) => ({
        enseignants: state.enseignants.filter(e => e.id !== id),
        affectations: state.affectations.filter(a => a.enseignantId !== id),
      })),

      // AffectationEnseignant CRUD
      addAffectation: (affectation) => set((state) => ({
        affectations: [...state.affectations, { ...affectation, id: uid() }],
      })),

      updateAffectation: (id, data) => set((state) => ({
        affectations: state.affectations.map(a => a.id === id ? { ...a, ...data } : a),
      })),

      deleteAffectation: (id) => set((state) => ({
        affectations: state.affectations.filter(a => a.id !== id),
      })),

      // Personnel CRUD
      addPersonnel: (personnel) => set((state) => ({
        personnels: [...state.personnels, { ...personnel, id: uid() }],
      })),

      updatePersonnel: (id, data) => set((state) => ({
        personnels: state.personnels.map(p => p.id === id ? { ...p, ...data } : p),
      })),

      deletePersonnel: (id) => set((state) => ({
        personnels: state.personnels.filter(p => p.id !== id),
      })),

      // Parametres
      updateParametres: (data) => set((state) => ({
        parametres: { ...state.parametres, ...data },
      })),

      toggleCycle: (cycle) => set((state) => {
        const current = state.parametres.cyclesActifs;
        const isActive = current.includes(cycle);
        const newCycles = isActive
          ? current.filter(c => c !== cycle)
          : [...current, cycle];
        return { parametres: { ...state.parametres, cyclesActifs: newCycles.length > 0 ? newCycles : [cycle] } };
      }),

      // Data Management
      generateClassesForCycle: (cycle) => {
        const state = get();
        const existing = state.classes.filter(cl => cl.cycle === cycle);
        if (existing.length === 0) {
          const niveaux = CYCLE_NIVEAUX[cycle];
          const newClasses: Classe[] = niveaux.map(niveau => ({
            id: uid(),
            nom: `Classe de ${niveau}`,
            niveau,
            cycle,
            capacite: 40,
            effectif: 0,
            anneeScolaire: state.parametres.anneeScolaire,
          }));
          set({ classes: [...state.classes, ...newClasses] });
        }
      },

      exportDataJSON: () => {
        const state = get();
        return JSON.stringify({
          eleves: state.eleves,
          classes: state.classes,
          notes: state.notes,
          presences: state.presences,
          bulletins: state.bulletins,
          cours: state.cours,
          parametres: state.parametres,
        });
      },

      importDataJSON: (json: string) => {
        try {
          const data = JSON.parse(json);
          if (!data || typeof data !== 'object') return false;
          const requiredKeys = ['eleves', 'classes', 'notes', 'presences', 'bulletins', 'cours', 'parametres'];
          for (const key of requiredKeys) {
            if (!Array.isArray(data[key]) && key !== 'parametres') return false;
            if (key === 'parametres' && typeof data[key] !== 'object') return false;
          }
          set({
            eleves: data.eleves || [],
            classes: data.classes || [],
            notes: data.notes || [],
            presences: data.presences || [],
            bulletins: data.bulletins || [],
            cours: data.cours || [],
            parametres: data.parametres || get().parametres,
          });
          return true;
        } catch {
          return false;
        }
      },

      // Helpers
      getClassesByCycle: (cycle) => get().classes.filter(c => c.cycle === cycle),

      getElevesByClasse: (classeId) => get().eleves.filter(e => e.classeId === classeId && e.statut === 'actif'),

      getNotesByEleve: (eleveId, periode) => {
        const notes = get().notes.filter(n => n.eleveId === eleveId);
        return periode !== undefined ? notes.filter(n => n.periode === periode) : notes;
      },

      getPresencesByEleve: (eleveId, date) => {
        const presences = get().presences.filter(p => p.eleveId === eleveId);
        return date ? presences.filter(p => p.date === date) : presences;
      },

      getBulletin: (eleveId, periode) =>
        get().bulletins.find(b => b.eleveId === eleveId && b.periode === periode),

      getAffectationsByClasse: (classeId) =>
        get().affectations.filter(a => a.classeId === classeId),

      getAffectationsByEnseignant: (enseignantId) =>
        get().affectations.filter(a => a.enseignantId === enseignantId),

      getCoursByClasse: (classeId) =>
        get().cours.filter(c => c.classeId === classeId).sort((a, b) => {
          const jourComp = JOURS_SEMAINE.indexOf(a.jour) - JOURS_SEMAINE.indexOf(b.jour);
          if (jourComp !== 0) return jourComp;
          return a.heureDebut.localeCompare(b.heureDebut);
        }),

      resetData: () => set({
        eleves: sampleEleves,
        classes: sampleClasses,
        notes: sampleNotes,
        presences: samplePresences,
        bulletins: sampleBulletins,
        cours: sampleCours,
        enseignants: sampleEnseignants,
        affectations: [],
        personnels: [],
        parametres: defaultParametres,
      }),
    }),
    {
      name: 'school-management-storage',
      version: 7,
      migrate: (persisted: any, version: number) => {
        const state = persisted as AppState;

        // Migration v0 -> v1: convert cycleActuel (string) to cyclesActifs (string[])
        if (!state.parametres || !Array.isArray(state.parametres.cyclesActifs)) {
          const oldCycle = (state.parametres as any)?.cycleActuel || 'Élémentaire';
          state.parametres = {
            ...state.parametres,
            cyclesActifs: Array.isArray((state.parametres as any)?.cyclesActifs)
              ? (state.parametres as any).cyclesActifs
              : [oldCycle],
          };
        }

        // Migration v1 -> v2: rename CP1 -> CI, CP2 -> CP
        if (version < 2 && state.classes) {
          const renameMap: Record<string, string> = { 'CP1': 'CI', 'CP2': 'CP' };
          state.classes = (state.classes as Classe[]).map(c => ({
            ...c,
            nom: renameMap[c.niveau] ? c.nom.replace(c.niveau, renameMap[c.niveau]) : c.nom,
            niveau: renameMap[c.niveau] || c.niveau,
          }));
        }

        // Migration v2 -> v3: add enseignants + affectations
        if (version < 3) {
          if (!Array.isArray(state.enseignants)) {
            state.enseignants = sampleEnseignants;
          }
          if (!Array.isArray(state.affectations)) {
            state.affectations = [];
          }
        }

        // Migration v3 -> v4: add typeClasse to classes
        if (version < 4 && state.classes) {
          state.classes = (state.classes as Classe[]).map(c => ({
            ...c,
            typeClasse: c.typeClasse || 'Simple',
          }));
        }

        // Migration v4 -> v5: add personnels array
        if (version < 5) {
          if (!Array.isArray(state.personnels)) {
            state.personnels = [];
          }
        }

        // Migration v5 -> v6: convert trimestre (number) to periode (string) for notes & bulletins
        if (version < 6) {
          if (Array.isArray(state.notes)) {
            state.notes = (state.notes as Note[]).map(n => {
              if (n.periode) return n;
              const oldT = (n as any).trimestre as number | undefined;
              const p: Periode = oldT === 1 ? 'T1' : oldT === 2 ? 'T2' : oldT === 3 ? 'T3' : 'T1';
              const { trimestre: _t, ...rest } = n as any;
              return { ...rest, periode: p };
            });
          }
          if (Array.isArray(state.bulletins)) {
            state.bulletins = (state.bulletins as Bulletin[]).map(b => {
              if (b.periode) return b;
              const oldT = (b as any).trimestre as number | undefined;
              const p: Periode = oldT === 1 ? 'T1' : oldT === 2 ? 'T2' : oldT === 3 ? 'T3' : 'T1';
              const { trimestre: _t, ...rest } = b as any;
              return { ...rest, periode: p };
            });
          }
        }

        // Migration v6 -> v7: ensure all new fields exist
        if (version < 7) {
          if (!Array.isArray(state.enseignants)) state.enseignants = [];
          if (!Array.isArray(state.affectations)) state.affectations = [];
          if (!Array.isArray(state.personnels)) state.personnels = [];
          // Ensure parametres has cyclesActifs
          if (state.parametres && !Array.isArray(state.parametres.cyclesActifs)) {
            state.parametres.cyclesActifs = [(state.parametres as any).cycleActuel || 'Élémentaire'];
          }
        }

        return state;
      },
      onRehydrateStorage: () => () => {},
    }
  )
);
