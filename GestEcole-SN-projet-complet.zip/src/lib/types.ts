// Types pour l'application de gestion scolaire sénégalaise

export type CycleType = 'Préscolaire' | 'Élémentaire' | 'Moyen' | 'Secondaire';
export type SexeType = 'M' | 'F';
export type StatutEleve = 'actif' | 'inactif';
export type StatutPresence = 'present' | 'absent' | 'retard';
export type Periode = 'T1' | 'T2' | 'T3' | 'S1' | 'S2';

// Périodes d'évaluation par cycle
// Élémentaire / Préscolaire : 3 trimestres
// Moyen / Secondaire : 2 semestres
export const CYCLE_PERIODES: Record<CycleType, Periode[]> = {
  'Préscolaire': ['T1', 'T2', 'T3'],
  'Élémentaire': ['T1', 'T2', 'T3'],
  'Moyen': ['S1', 'S2'],
  'Secondaire': ['S1', 'S2'],
};

export const PERIODE_LABELS: Record<Periode, string> = {
  'T1': '1er Trimestre',
  'T2': '2ème Trimestre',
  'T3': '3ème Trimestre',
  'S1': '1er Semestre',
  'S2': '2ème Semestre',
};

export const getPeriodesForCycle = (cycle: CycleType): Periode[] => CYCLE_PERIODES[cycle];
export const getPeriodeLabel = (periode: Periode): string => PERIODE_LABELS[periode];

export const CYCLE_NIVEAUX: Record<CycleType, string[]> = {
  'Préscolaire': ['PS', 'MS', 'GS'],
  'Élémentaire': ['CI', 'CP', 'CE1', 'CE2', 'CM1', 'CM2'],
  'Moyen': ['6ème', '5ème', '4ème', '3ème'],
  'Secondaire': ['2nde', '1ère', 'Tle'],
};

export const MATIERES: Record<CycleType, string[]> = {
  'Préscolaire': ['Éveil', 'Dessin', 'Musique', 'Éducation Physique', 'Langue'],
  'Élémentaire': ['Mathématiques', 'Français', 'Anglais', 'Sciences', 'Histoire-Géo'],
  'Moyen': ['Mathématiques', 'Français', 'Anglais', 'Physique-Chimie', 'SVT', 'Histoire-Géo', 'EPS'],
  'Secondaire': ['Mathématiques', 'Français', 'Anglais', 'Physique-Chimie', 'SVT', 'Philosophie', 'Histoire-Géo'],
};

export const JOURS_SEMAINE = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi'];

export interface Eleve {
  id: string;
  nom: string;
  prenom: string;
  dateNaissance: string;
  sexe: SexeType;
  classeId: string;
  cycle: CycleType;
  parentContact: string;
  adresse: string;
  photo: string;
  statut: StatutEleve;
}

export interface EnseignantClasse {
  titre: 'Monsieur' | 'Madame';
  prenom: string;
  nom: string;
  nomDeMari?: string;
}

export interface Classe {
  id: string;
  nom: string;
  niveau: string;
  cycle: CycleType;
  capacite: number;
  effectif: number;
  anneeScolaire: string;
  typeClasse?: 'Simple' | 'CMG' | 'CDF';
  enseignant?: EnseignantClasse;
  professeurResponsable?: EnseignantClasse;
}

export interface Note {
  id: string;
  eleveId: string;
  matiere: string;
  note: number;
  coefficient: number;
  periode: Periode;
  date: string;
  commentaire: string;
}

export interface Presence {
  id: string;
  eleveId: string;
  date: string;
  statut: StatutPresence;
  motif: string;
}

export interface Bulletin {
  id: string;
  eleveId: string;
  periode: Periode;
  anneeScolaire: string;
  appreciation: string;
  mention: string;
  moyenne: number;
  rang: number;
}

export interface Enseignant {
  id: string;
  nom: string;
  prenom: string;
  sexe: SexeType;
  telephone: string;
  email: string;
  specialite: string;
  statut: 'actif' | 'inactif';
}

export interface AffectationEnseignant {
  id: string;
  enseignantId: string;
  classeId: string;
  matiere: string;
  role: 'titulaire' | 'remplacant';
}

export interface Cours {
  id: string;
  matiere: string;
  classeId: string;
  jour: string;
  heureDebut: string;
  heureFin: string;
  enseignant: string;
  salle: string;
}

export type FonctionPersonnel = 'Enseignant' | 'Directeur' | 'Directeur adjoint' | 'Surveillant' | 'Censeur' | 'Éducateur' | 'Secrétaire' | 'Comptable' | 'Agent de service' | 'Conciergerie' | 'Autre';

export interface Personnel {
  id: string;
  nom: string;
  prenom: string;
  dateNaissance: string;
  sexe: SexeType;
  fonction: FonctionPersonnel;
  telephone: string;
  email: string;
  adresse: string;
  specialite: string;
  statut: 'actif' | 'inactif';
}

export interface Parametres {
  cyclesActifs: CycleType[];
  anneeScolaire: string;
  nomEcole: string;
  adresse: string;
  telephone: string;
  logo: string;
}

export type ViewType = 'dashboard'
  | 'eleves' | 'eleve-ajouter' | 'eleve-liste' | 'eleve-dossier' | 'eleve-affectation' | 'eleve-transfert' | 'eleve-archives'
  | 'classes' | 'classe-creer' | 'classe-liste' | 'classe-affecter-eleves' | 'classe-affecter-enseignants'
  | 'personnel' | 'personnel-ajouter' | 'personnel-liste' | 'personnel-dossier' | 'personnel-affectation' | 'personnel-transfert' | 'personnel-archives'
  | 'notes' | 'bulletins' | 'presences' | 'emploi-du-temps' | 'parametres';
